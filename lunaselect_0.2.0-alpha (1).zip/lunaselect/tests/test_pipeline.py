import json, os, shutil, stat, sys, time, unittest
import numpy as np
from _util import *
from lunaselect import geo, pipeline, report, cli, synthetic, terrain as T
from lunaselect.workspace import Workspace, sha256_file


class TestWorkspace(unittest.TestCase):
    def test_immutable_originals_identity_and_dedupe(self):
        ws, a, b, _ = demo_workspace(run=False); p = ws.root / a["stored_path"]
        self.assertEqual(stat.S_IMODE(os.stat(p).st_mode) & 0o222, 0); self.assertEqual(sha256_file(p), a["sha256"])
        self.assertEqual(b["site"]["project_site_id"], "Site 11"); self.assertEqual(b["site"]["filename_hint"], "Site 1"); self.assertFalse(b["site"]["hint_agrees"])   # Site01 filename, project identity stays Site 11
        self.assertEqual(ws.ingest(str(ws.root.parent / "in" / "Site11_synthetic_dem.tif"))["id"], a["id"]); self.assertEqual(len(ws.datasets()), 2)
        self.assertTrue(a["synthetic"]); self.assertEqual(a["data_class"], "simulated"); self.assertEqual(ws.verify_integrity(), [])
        os.chmod(p, 0o644); open(p, "ab").write(b"x"); self.assertEqual(ws.verify_integrity(), [a["id"]])           # tampering is detected

    def test_corrupt_truncated_and_foreign_files(self):
        ws, a, _, _ = demo_workspace(run=False); d = tmpdir()
        open(d + "/bad.tif", "wb").write(b"II*\x00garbage"); raw = open(ws.root / a["stored_path"], "rb").read(); open(d + "/trunc.tif", "wb").write(raw[:len(raw) // 3])
        open(d + "/x.img", "wb").write(b"PDS3"); open(d + "/v.gpkg", "wb").write(b"SQLite")
        self.assertEqual(ws.ingest(d + "/bad.tif")["status"], "UNREADABLE"); t = ws.ingest(d + "/trunc.tif"); self.assertIn(t["status"], ("UNREADABLE", "READY"))
        if t["status"] == "READY": self.assertNotEqual(t["quality"]["status"], "PASS")
        i = ws.ingest(d + "/x.img"); self.assertEqual(i["status"], "STORED_NOT_PARSED"); self.assertIn("not_implemented", i["adapter"]["status"]); self.assertIn("blocked", ws.ingest(d + "/v.gpkg")["adapter"]["status"])

    def test_type_confirmation_history(self):
        d = tmpdir(); ws = Workspace.create(d + "/ws", "T", "Site 11"); p = d + "/Site11_Roughness.tif"
        write_plane(p, np.random.rand(40, 40) * 10, georef=geo.GeoRef(0, 400, 10.0, 10.0)); r = ws.ingest(p)
        self.assertTrue(r["dataset_type"]["needs_user_confirmation"]); self.assertIsNone(ws.effective_type(r["id"]))
        ws.confirm_type(r["id"], "roughness", "analyst1", "checked product label"); self.assertEqual(ws.effective_type(r["id"]), "roughness")
        h = ws.get(r["id"])["processing_history"]; self.assertEqual(h[-1]["step"], "confirm_type"); self.assertEqual(h[-1]["by"], "analyst1")
        with self.assertRaises(ValueError): ws.confirm_type(r["id"], "nonsense", "x")

    def test_unknown_crs_slope_only_and_earth_crs_refused(self):
        d = tmpdir(); ws = Workspace.create(d + "/ws", "T", "Site 11")
        e = ws.ingest(self._dem(d + "/Site11_dem.tif", geo.earth_wgs84_keys(), geo.GeoRef(0, 40, 1, 1)))
        with self.assertRaises(ValueError): pipeline.run_site(ws, e["id"], fast_cfg())
        u = ws.ingest(self._dem(d + "/Site11_dem2.tif", {}, geo.GeoRef(0, 4000, 100.0, 100.0)))
        with self.assertRaises(ValueError): pipeline.run_site(ws, u["id"], fast_cfg())
        s = ws.ingest(self._dem(d + "/Site11_slope.tif", geo.moon_polar_stereo_keys(), geo.GeoRef(0, 4000, 100.0, 100.0), units="deg", vals=np.random.rand(40, 40) * 20))
        with self.assertRaises(ValueError): pipeline.run_site(ws, s["id"], fast_cfg())                                      # slope raster alone is not a DEM

    @staticmethod
    def _dem(p, keys, g, units="m", vals=None):
        a = (np.random.default_rng(0).random((40, 40)) * 5 if vals is None else vals).astype("float32"); geo.write_geotiff(p, a, g, keys, nodata=-9999, units=units, tags={"LUNASELECT_TYPE": "dem" if units == "m" else "slope"}); return p

    def test_large_raster_ingest_and_slope(self):
        d = tmpdir(); n = 2500; z = (np.add.outer(np.arange(n), np.arange(n)) * 0.5).astype("float32"); p = d + "/big_dem.tif"
        geo.write_geotiff(p, z, geo.GeoRef(-n * 10 / 2, n * 10 / 2 + 30000, 10.0, 10.0), geo.moon_polar_stereo_keys(), nodata=-9999, units="m", tags={"LUNASELECT_TYPE": "dem"})
        ws = Workspace.create(d + "/ws", "T", "Site 11"); t = time.time(); r = ws.ingest(p); rr = ws.raster(r["id"]); dx, dy, _ = geo.ground_spacing(rr); s = T.slope_deg(*T.horn_gradient(rr.as_float(), dx, dy))
        self.assertEqual(r["quality"]["status"], "PASS"); self.assertTrue(np.isfinite(s[100, 100])); self.assertLess(time.time() - t, 60)


class TestPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ws, cls.a, cls.b, cls.res = demo_workspace(days=2.0)

    def test_products_and_evaluation(self):
        ws, res = self.ws, self.res
        for n in ("slope", "aspect", "curvature", "local_relief", "roughness", "illumination_fraction", "earth_visibility_fraction"): self.assertTrue((ws.root / "derived" / f"{n}.tif").exists(), n)
        ev = res["evaluation"]; self.assertEqual(ev["status"], "PASS"); self.assertTrue(res["synthetic"]); self.assertLessEqual(ev["score_coverage"], 1.0)
        self.assertEqual(len([c for c in json.load(open(ws.root / "derived/crater_candidates.json"))["candidates"] if c["confidence"] != "very_low"]), 3)
        self.assertEqual({x["status"] for x in ev["factors"] if x["factor"] in ("slope", "roughness")}, {"ASSESSED"}); self.assertEqual(ws.verify_integrity(), [])
        dv = ws.get(res["derived"]["slope"]); self.assertEqual(dv["processing_history"][0]["inputs"][0]["sha256"], self.a["sha256"]); self.assertTrue(dv["synthetic"])
        self.assertLess(res["factor_inputs"]["illumination_duration"]["coverage"], 1.0)                                    # edge pixels flagged incomplete, not hidden

    def test_reports_and_exports(self):
        paths = report.build_all(self.ws); rep = json.load(open(paths["json"]))
        self.assertTrue(rep["synthetic_demo"]); self.assertIn("not NASA/JPL", rep["disclaimer"]); self.assertEqual(len(rep["factor_coverage"]), 20); self.assertEqual(sum(c["assessed"] for c in rep["factor_coverage"]), 6)
        self.assertIn("NOT_ASSESSED", open(paths["csv"]).read()); self.assertEqual(open(paths["pdf"], "rb").read(5), b"%PDF-")
        o = cli.export_mesh(self.ws, self.a["id"], "obj", 2.0, 4); txt = open(o).read(); self.assertIn("# synthetic: True", txt); self.assertIn("# crs:", txt); self.assertIn("not a model from slope alone", txt)
        with self.assertRaises(geo.UnsupportedError) if not _has("trimesh") else unittest.TestCase.subTest(self): cli.export_mesh(self.ws, self.a["id"], "glb", 1.0, 4)

    def test_reproducibility(self):
        ws2, a2, _, res2 = demo_workspace(days=2.0)
        for n in ("slope", "roughness", "illumination_fraction", "earth_visibility_fraction"): self.assertEqual(self.ws.get(self.res["derived"][n])["sha256"], ws2.get(res2["derived"][n])["sha256"], n)
        self.assertEqual(self.res["evaluation"]["score"], res2["evaluation"]["score"])

    def test_insufficient_coverage_blocks_pass(self):
        d = tmpdir(); ws = Workspace.create(d + "/ws", "T", "Site 11"); z, g, _ = synthetic.synthetic_dem(n=160); z[:, :100] = np.nan
        p = d + "/Site11_dem.tif"; geo.write_geotiff(p, np.where(np.isfinite(z), z, -9999), g, geo.moon_polar_stereo_keys(), nodata=-9999, units="m", tags={"LUNASELECT_TYPE": "dem", "SYNTHETIC": "true"})
        cfg = fast_cfg(1.0); res = pipeline.run_site(ws, ws.ingest(p)["id"], cfg); self.assertIn(res["evaluation"]["gates"][0]["status"], ("INSUFFICIENT_DATA", "FAIL")); self.assertNotEqual(res["evaluation"]["status"], "PASS")


def _has(m):
    try: __import__(m); return True
    except ImportError: return False
