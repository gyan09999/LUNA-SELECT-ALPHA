import os, unittest
import numpy as np, tifffile
from _util import *
from lunaselect import geo, terrain as T, ephemeris as E


class TestGeo(unittest.TestCase):
    def test_roundtrip_and_independent_parser(self):
        p = tmpdir() + "/a.tif"; a = np.random.rand(30, 40).astype("float32"); a[0, 0] = -9999
        g = geo.GeoRef(-20000.0, 15000.0, 1000.0, 1000.0); geo.write_geotiff(p, a, g, geo.moon_polar_stereo_keys(), nodata=-9999, units="m", description="dem", tags={"K": "v"})
        r = geo.read_geotiff(p)
        self.assertEqual((r.georef.x0, r.georef.y0, r.georef.sx), (-20000.0, 15000.0, 1000.0)); self.assertEqual((r.crs.body, r.crs.projection), ("moon", "polar_stereographic"))
        self.assertEqual((r.units, r.description, r.tags["K"], r.nodata), ("m", "dem", "v", -9999.0)); self.assertEqual(int(r.nodata_mask().sum()), 1)
        with tifffile.TiffFile(p) as t:                       # independent implementation (tifffile) must agree
            m = t.geotiff_metadata
            self.assertEqual(list(m["ModelTiepoint"])[3:5], [-20000.0, 15000.0]); self.assertEqual(m["GeogSemiMajorAxisGeoKey"], 1737400.0)

    def test_crs_classification(self):
        d = tmpdir(); z = np.zeros((5, 5))
        self.assertEqual(write_plane(d + "/m.tif", z, geo.moon_geographic_keys()).crs.body, "moon")
        self.assertEqual(write_plane(d + "/e.tif", z, geo.earth_wgs84_keys()).crs.body, "earth")
        self.assertEqual(write_plane(d + "/n.tif", z, {}).crs.body, "unknown")

    def test_pixel_is_point_and_rotation(self):
        d = tmpdir(); k = geo.moon_geographic_keys(); k[1025] = 2
        r = write_plane(d + "/p.tif", np.zeros((4, 4)), k, georef=geo.GeoRef(10.0, 20.0, 1.0, 1.0)); self.assertEqual((r.georef.x0, r.georef.y0), (9.5, 20.5))
        tr = [0.9, 0.1, 0, 5.0, 0.1, -0.9, 0, 7.0, 0, 0, 0, 0, 0, 0, 0, 1]; gkd, db, asc = geo.build_geokeys(geo.moon_geographic_keys())
        tifffile.imwrite(d + "/r.tif", np.zeros((4, 4), "float32"), metadata=None, extratags=[(geo.T_TRANS, "d", 16, tr, True), (geo.T_GKD, "H", len(gkd), gkd, True), (geo.T_GDBL, "d", len(db), db, True)])
        self.assertTrue(geo.read_geotiff(d + "/r.tif").georef.rotated)

    def test_projection_roundtrip_and_pole(self):
        r = write_plane(tmpdir() + "/p.tif", np.zeros((50, 50)), spacing=2000.0, georef=geo.GeoRef(-50000.0, 50000.0, 2000.0, 2000.0))
        lon, lat = geo.lonlat_of(r, np.array([10.0, 30.0]), np.array([5.0, 40.0])); x, y = geo.xy_of(r.crs, lon, lat)
        pr, pc = geo.pixel_of(r, lon, lat); np.testing.assert_allclose([pr, pc], [[10.0, 30.0], [5.0, 40.0]], atol=1e-6)
        c = np.radians(5.0); rho = 2 * geo.MOON_R * np.tan(c / 2); rr = write_plane(tmpdir() + "/q.tif", np.zeros((3, 3)), georef=geo.GeoRef(rho - 1.5, 1.5, 1.0, 1.0))
        self.assertAlmostEqual(float(geo.lonlat_of(rr, 1, 1)[1]), -85.0, places=3)

    def test_stereographic_scale_factor(self):
        r = write_plane(tmpdir() + "/s.tif", np.zeros((200, 200)), spacing=1000.0, georef=geo.GeoRef(-100000.0, 100000.0, 1000.0, 1000.0))
        dx, _, _ = geo.ground_spacing(r); k = 2 / (1 + np.cos(2 * np.arctan(np.hypot(99500.0, 99500.0) / (2 * geo.MOON_R))))
        self.assertAlmostEqual(float(dx[0, 0]), 1000.0 / float(k), places=4); self.assertLess(float(dx[0, 0]), 1000.0)

    def test_resample_cross_crs_and_oversampling_flag(self):
        src = write_plane(tmpdir() + "/s.tif", np.zeros((120, 120)), spacing=500.0, georef=geo.GeoRef(-30000.0, 30000.0, 500.0, 500.0))
        lon, lat = geo.lonlat_of(src, *np.meshgrid(np.arange(120), np.arange(120), indexing="ij")); f = lambda lo, la: 100 * (la + 88) + 30 * np.sin(np.radians(lo))
        src.data = f(lon, lat).astype("float32")
        dst = geo.Raster("", (40, 40), "f4", 1, geo.GeoRef(-1.0, -89.2, 0.0125, 0.0125), geo.crs_from_keys(geo.moon_geographic_keys()), None, None, None, {})
        out, m = geo.resample(src, dst); lon2, lat2 = geo.lonlat_of(dst, *np.meshgrid(np.arange(40), np.arange(40), indexing="ij")); ok = np.isfinite(out)
        self.assertGreater(ok.mean(), 0.2); self.assertLess(float(np.abs(out[ok] - f(lon2, lat2)[ok]).max()), 1.0)
        fine = geo.Raster("", (200, 200), "f4", 1, geo.GeoRef(-1.0, -88.5, 0.0003, 0.0003), dst.crs, None, None, None, {})
        self.assertTrue(geo.resample(src, fine)[1]["oversampled"]); self.assertIsNotNone(geo.resample(src, fine)[1]["warning"])


class TestTerrain(unittest.TestCase):
    def test_plane_slope_exact(self):
        n = 40; x = np.arange(n) * 10.0
        for deg in (1, 10, 30):
            z = np.tile(x * np.tan(np.radians(deg)), (n, 1)); s = T.slope_deg(*T.horn_gradient(z, 10.0, 10.0))
            self.assertAlmostEqual(float(np.nanmax(np.abs(s - deg))), 0.0, places=3)
            self.assertAlmostEqual(float(np.nanmean(T.slope_deg(*T.horn_gradient(z, 10.0, 10.0, stride=3)) - deg)), 0.0, places=3)

    def test_nodata_not_filled(self):
        z = np.zeros((20, 20), np.float32); z[10, 10] = np.nan; s = T.slope_deg(*T.horn_gradient(z, 1.0, 1.0))
        self.assertTrue(np.isnan(s[9:12, 9:12]).all()); self.assertTrue(np.isfinite(s[3, 3])); self.assertTrue(np.isnan(s[0, :]).all())

    def test_cone_needs_scale_correction(self):
        n, sp = 200, 6000.0; r = write_plane(tmpdir() + "/c.tif", np.zeros((n, n)), spacing=sp, georef=geo.GeoRef(-n * sp / 2, n * sp / 2, sp, sp))
        rows, cols = np.meshgrid(np.arange(n), np.arange(n), indexing="ij"); x = (cols + .5) * sp - n * sp / 2; y = n * sp / 2 - (rows + .5) * sp
        g = 2 * geo.MOON_R * np.arctan(np.hypot(x, y) / (2 * geo.MOON_R)); z = (np.tan(np.radians(10)) * g).astype(np.float64)
        dx, dy, _ = geo.ground_spacing(r, True); good = T.slope_deg(*T.horn_gradient(z, dx, dy)); dx0, dy0, _ = geo.ground_spacing(r, False); bad = T.slope_deg(*T.horn_gradient(z, dx0, dy0))
        m = np.zeros_like(z, bool); m[:, :] = True; m &= np.hypot(x, y) > 350000
        self.assertLess(abs(float(np.nanmedian(good[m])) - 10.0), 0.05); self.assertGreater(abs(float(np.nanmedian(bad[m])) - 10.0), 0.1)

    def test_hillshade_aspect_curvature_relief_roughness(self):
        n = 61; x = (np.arange(n) - 30) * 10.0; X, Y = np.meshgrid(x, x)
        self.assertAlmostEqual(float(T.hillshade(np.zeros((5, 5)), np.zeros((5, 5)), 315, 45)[0, 0]), np.sin(np.radians(45)), places=5)
        gx, gy = T.horn_gradient(0.2 * X, 10.0, 10.0); self.assertAlmostEqual(float(np.nanmedian(T.aspect_deg(gx, gy))), 270.0, places=3)   # rises eastward -> faces west
        self.assertAlmostEqual(float(np.nanmean(T.curvature(1e-3 * (X ** 2 + Y ** 2), 10.0, 10.0)[5:-5, 5:-5])), 4e-3, places=6)
        self.assertAlmostEqual(float(np.nanmax(T.local_relief(2.0 * X, 5)[5:-5, 5:-5])), 2.0 * 40, places=3)
        self.assertLess(float(np.nanmax(T.roughness_rms(0.2 * X + 0.1 * Y, 7))), 1e-4)
        nz = np.random.default_rng(0).normal(0, 2.0, (n, n)); self.assertAlmostEqual(float(np.nanmean(T.roughness_rms(nz, 15))), 2.0 * np.sqrt(222 / 225), delta=0.1)

    def test_crater_detection_vs_truth(self):
        z, g, truth = synthetic.synthetic_dem(); cs, info = T.detect_craters(z, 50.0, [150, 200, 260, 340, 450, 600])
        good = [c for c in cs if c["confidence"] != "very_low"]; self.assertEqual(len(good), 3)
        for t in truth:
            m = [c for c in good if abs(c["row"] - t["row"]) <= 2 and abs(c["col"] - t["col"]) <= 2]; self.assertEqual(len(m), 1, t)
            self.assertLess(abs(m[0]["diameter_m"] - t["diameter_m"]) / t["diameter_m"], 0.20); self.assertLess(abs(m[0]["depth_m"] - 0.15 * t["diameter_m"]) / (0.15 * t["diameter_m"]), 0.10)
        self.assertTrue(all(c["review_status"] == "needs_review" for c in cs))
        self.assertEqual(len([c for c in T.detect_craters(np.zeros((200, 200)) + np.random.default_rng(1).normal(0, .05, (200, 200)), 50.0, [150, 300])[0] if c["confidence"] != "very_low"]), 0)


class TestEphemeris(unittest.TestCase):
    U = lambda *a: __import__("datetime").datetime(*a, tzinfo=__import__("datetime").timezone.utc).timestamp()

    def test_apollo_sun_elevation(self):   # regression values (this model) + approximate reference values recalled from mission records (NOT independently verified)
        for t, la, lo, model, ref in [((1969, 7, 20, 20, 17, 40), 0.674, 23.473, 10.70, 10.8), ((1969, 11, 19, 6, 54, 35), -3.013, -23.422, 5.15, 5.6),
                                      ((1971, 7, 30, 22, 16, 29), 26.132, 3.634, 12.02, 12.0), ((1972, 12, 11, 19, 54, 57), 20.191, 30.772, 13.34, 13.3)]:
            el = float(E.sun_look(la, lo, TestEphemeris.U(*t))[0]); self.assertAlmostEqual(el, model, delta=0.02); self.assertLess(abs(el - ref), 0.6)

    def test_meeus_libration_and_subsolar(self):
        p = E.sub_points(TestEphemeris.U(1992, 4, 12)); self.assertAlmostEqual(float(p["earth_lon"]), -1.206, delta=0.1); self.assertAlmostEqual(float(p["earth_lat"]), 4.194, delta=0.05)
        t = TestEphemeris.U(2026, 11, 10); p = E.sub_points(t); self.assertAlmostEqual(float(E.sun_look(p["sun_lat"], p["sun_lon"], t)[0]), 90.0, places=4)
        self.assertEqual(E.sun_look(np.zeros(3), np.zeros(3), np.array([t, t + 3600, t + 7200]))[0].shape, (3,))
