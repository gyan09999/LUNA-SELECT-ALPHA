import copy, os, sys, tempfile, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from lunaselect import geo, pipeline, synthetic
from lunaselect.workspace import Workspace


def tmpdir():
    return tempfile.mkdtemp(prefix="lunaselect_test_")


def fast_cfg(days=2.0):
    c = copy.deepcopy(pipeline.DEMO_CFG); c["analysis"]["environment"].update(days=days, step_h=12.0, max_shadow_dist_m=2000.0); return c


def demo_workspace(days=2.0, run=True):
    d = tmpdir(); pd, ps = synthetic.write_site11_demo(d + "/in")
    ws = Workspace.create(d + "/ws", "T", "Site 11"); a = ws.ingest(pd); b = ws.ingest(ps)
    res = pipeline.run_site(ws, a["id"], fast_cfg(days)) if run else None
    return ws, a, b, res


def write_plane(path, arr, keys=None, spacing=10.0, nodata=None, units="m", georef=None, tags=None):
    g = georef or geo.GeoRef(0.0, arr.shape[0] * spacing, spacing, spacing)
    geo.write_geotiff(path, arr.astype(np.float32), g, geo.moon_polar_stereo_keys() if keys is None else keys, nodata=nodata, units=units, tags=tags or {})
    return geo.read_geotiff(path)
