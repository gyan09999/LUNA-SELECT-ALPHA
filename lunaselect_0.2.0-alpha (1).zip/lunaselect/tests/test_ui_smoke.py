"""Smoke test of the Streamlit pages with a STUB streamlit module (no browser, no real Streamlit). Verifies the page code runs against the real core API."""
import sys, types, unittest
from _util import *


class D:
    def __call__(self, *a, **k): return D()
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __iter__(self): return iter([D(), D(), D(), D()])
    def __getattr__(self, n): return D()
    def __bool__(self): return False


class FakeSt(types.ModuleType):
    session_state = {}
    def __init__(self): super().__init__("streamlit"); self.sidebar = self
    def __getattr__(self, n): return D()
    button = checkbox = staticmethod(lambda *a, **k: False)
    file_uploader = staticmethod(lambda *a, **k: [])
    selectbox = staticmethod(lambda label, opts, *a, **k: list(opts)[0])
    radio = staticmethod(lambda label, opts, *a, **k: list(opts)[0])
    text_input = staticmethod(lambda label, value="", *a, **k: value)
    text_area = staticmethod(lambda label, value="", *a, **k: value)
    number_input = staticmethod(lambda label, mn=0.0, mx=1.0, v=None, *a, **k: v if v is not None else mn)
    slider = staticmethod(lambda label, mn, mx, v, *a, **k: v)
    columns = staticmethod(lambda n, *a, **k: [D() for _ in range(n if isinstance(n, int) else len(n))])


class TestUi(unittest.TestCase):
    def test_all_pages_run(self):
        fake = FakeSt(); sys.modules["streamlit"] = fake
        from lunaselect.ui import app
        ws, a, b, res = demo_workspace(days=1.0); fake.session_state["ws_path"] = str(ws.root)
        self.assertEqual(len(app.PAGES), 14)
        for name, fn in app.PAGES.items(): fn(app._ws() if name != "Project Manager" else app._ws())
