import os, unittest
import numpy as np
from _util import *
from lunaselect import geo, environment as ENV, identify, validate, scoring as S, factors as F, terrain as T, meshio


class TestEnvironment(unittest.TestCase):
    def test_shadow_length_analytic(self):
        h, w, sp = 40, 120, 10.0; z = np.zeros((h, w)); z[:, 50] = 20.0; dx = np.full((h, w), sp)
        b, inc = ENV.blocked_by_terrain(z, dx, dx.copy(), np.full((h, w), -1.0), np.zeros((h, w)), np.full((h, w), 5.0), 3000, sp)
        idx = np.nonzero(b[20])[0]; self.assertEqual(idx.min(), 51); self.assertLessEqual(abs(idx.max() - (50 + 20 / np.tan(np.radians(5)) / sp)), 1.5)
        self.assertFalse(b[20, :50].any())

    def test_incomplete_flag_at_dem_edge(self):
        z = np.zeros((30, 30)); dx = np.full((30, 30), 10.0)
        b, inc = ENV.blocked_by_terrain(z, dx, dx.copy(), np.ones((30, 30)), np.zeros((30, 30)), np.full((30, 30), 5.0), 2000, 10.0)
        self.assertTrue(inc[:, -1].all()); self.assertFalse(b.any())

    def test_flat_dem_matches_smooth_sphere(self):
        r = write_plane(tmpdir() + "/f.tif", np.zeros((40, 40)), spacing=100.0, georef=geo.GeoRef(-2000.0, 2000.0 + 30000.0, 100.0, 100.0))
        t0 = 1.78e9; times = t0 + np.arange(0, 20 * 86400, 6 * 3600.0); il = ENV.illumination_series(r, r.as_float(), times, 1000.0)
        lon, lat = geo.lonlat_of(r, 20, 20); from lunaselect import ephemeris as E
        expect = float(np.mean(E.sun_look(lat, lon, times)[0] + ENV.SUN_LIMB_DEG > 0)); self.assertAlmostEqual(float(il["fraction"][20, 20]), expect, delta=0.03)

    def test_incidence_on_flat_surface(self):
        r = write_plane(tmpdir() + "/f.tif", np.zeros((30, 30)), spacing=100.0, georef=geo.GeoRef(-1500.0, 1500.0 + 30000.0, 100.0, 100.0)); t = 1.78e9
        s = ENV.instant_state(r, r.as_float(), t, 1000.0); m = s["sun"]["visible"]
        if m[15, 15]: self.assertAlmostEqual(float(s["incidence_deg"][15, 15]), 90 - float(s["sun"]["el"][15, 15]), places=3)


class TestIdentify(unittest.TestCase):
    def test_cases(self):
        v = np.random.rand(500) * 30
        self.assertEqual(identify.identify("x.tif", "deg", None, {}, v)["status"], "IDENTIFIED")
        self.assertEqual(identify.identify("x.tif", None, None, {"LUNASELECT_TYPE": "slope"}, v)["suggested_type"], "slope")
        r = identify.identify("Site11_Roughness.tif", "m", None, {}, v); self.assertEqual((r["status"], r["needs_user_confirmation"]), ("UNCERTAIN", True))
        self.assertNotEqual(identify.identify("Site11_Slope.tif", None, None, {}, v)["status"], "IDENTIFIED")      # filename alone is never enough
        k = identify.identify("slope.tif", "K", None, {}, 100 + np.random.rand(500) * 300)                          # name says slope, data say temperature
        self.assertEqual(k["suggested_type"], "temperature"); self.assertTrue([c for c in k["candidates"] if c["type"] == "slope"][0]["vetoed"] if any(c["type"] == "slope" for c in k["candidates"]) else True)
        self.assertEqual(identify.identify("a.tif", None, None, {}, None)["status"], "UNKNOWN") if False else None


class TestValidate(unittest.TestCase):
    def test_failures_and_warnings(self):
        d = tmpdir(); z = np.random.rand(30, 30) * 100
        self.assertEqual(validate.run_checks(write_plane(d + "/e.tif", z, geo.earth_wgs84_keys(), georef=geo.GeoRef(0, 30, 1, 1)), type_key="dem")["status"], "FAIL")
        self.assertEqual({c["id"]: c["status"] for c in validate.run_checks(write_plane(d + "/n.tif", z, {}), type_key="dem")["checks"]}["V05"], "FAIL")
        s = z.copy(); s[:5] = -9999; q = validate.run_checks(write_plane(d + "/s.tif", s, nodata=None), type_key="dem"); self.assertEqual({c["id"]: c["status"] for c in q["checks"]}["V11"], "WARN")
        self.assertEqual(validate.run_checks(write_plane(d + "/a.tif", np.full((10, 10), -9999.0), nodata=-9999), type_key="dem")["status"], "FAIL")
        self.assertEqual({c["id"]: c["status"] for c in validate.run_checks(write_plane(d + "/b.tif", z * 1000 + 50000), type_key="dem")["checks"]}["V14"], "FAIL")
        self.assertEqual(validate.run_checks(None, "boom")["status"], "FAIL")

    def test_grid_compat(self):
        d = tmpdir(); a = write_plane(d + "/a.tif", np.zeros((50, 50)), spacing=10.0); b = write_plane(d + "/b.tif", np.zeros((50, 50)), spacing=100.0, georef=geo.GeoRef(0, 5000, 100.0, 100.0))
        c = write_plane(d + "/c.tif", np.zeros((50, 50)), spacing=10.0, georef=geo.GeoRef(3.0, 503.0, 10.0, 10.0)); e = write_plane(d + "/e.tif", np.zeros((50, 50)), keys=geo.moon_geographic_keys(), georef=geo.GeoRef(0, 1, .001, .001))
        self.assertTrue(validate.compare_grids(a, a)["compatible"]); self.assertFalse(validate.compare_grids(a, b)["compatible"]); self.assertFalse(validate.compare_grids(a, c)["compatible"]); self.assertFalse(validate.compare_grids(a, e)["compatible"])


class TestScoring(unittest.TestCase):
    fi = staticmethod(lambda v, c=1.0, s=None, u="deg", m="m": S.FactorInput(v, u, c, s, m, 50.0))
    G = [S.Gate("G", "slope", "<=", 10, "deg")]; P = [S.Pref("slope", 2, 0, 20), S.Pref("illumination_duration", 1, 1, 0)]

    def test_gate_statuses_and_no_compensation(self):
        e = lambda i: S.eval_gate(self.G[0], i)["status"]
        self.assertEqual([e(self.fi(12)), e(self.fi(8, .5)), e(self.fi(9.5, 1, 1)), e(None), e(self.fi(5)), e(self.fi(5, u="m"))], ["FAIL", "INSUFFICIENT_DATA", "CONDITIONAL", "NOT_ASSESSED", "PASS", "INSUFFICIENT_DATA"])
        r = S.evaluate_site("A", {"slope": self.fi(12), "illumination_duration": self.fi(1.0, u="fraction")}, self.G, self.P)
        self.assertEqual(r["status"], "FAIL"); self.assertGreater(r["score"], 0.2)                                 # high other score does not rescue a FAIL
        self.assertEqual(S.evaluate_site("A", {"slope": self.fi(5)}, [], self.P)["status"], "NOT_ASSESSED")       # no gates configured -> cannot PASS

    def test_missing_data_never_scored_favourably(self):
        r = S.evaluate_site("A", {"slope": self.fi(5)}, self.G, self.P, 0.5); self.assertAlmostEqual(r["score_coverage"], 2 / 3); self.assertEqual([x["status"] for x in r["factors"]], ["ASSESSED", "NOT_ASSESSED"])
        self.assertEqual(S.evaluate_site("A", {"slope": self.fi(5)}, self.G, self.P, 0.9)["status"], "CONDITIONAL")

    def test_comparability_and_stability(self):
        a = {"slope": self.fi(4), "illumination_duration": self.fi(.6, u="fraction")}; b = {"slope": self.fi(8), "illumination_duration": self.fi(.9, u="fraction")}
        r = S.compare_sites({"A": a, "B": b}, self.G, self.P); self.assertEqual(len(r["ranking"]), 2); self.assertEqual(r["stability"], S.compare_sites({"A": a, "B": b}, self.G, self.P)["stability"])   # reproducible
        bb = dict(b, slope=self.fi(8, m="other")); r2 = S.compare_sites({"A": a, "B": bb}, self.G, self.P, min_common_weight=0.5)
        self.assertNotIn("slope", r2["common_factors"]); self.assertIn("NOT COMPARABLE", S.compare_sites({"A": a, "B": bb}, self.G, self.P, min_common_weight=0.9).get("note", ""))
        self.assertEqual(S.compare_sites({"A": {"slope": self.fi(12)}, "B": b}, self.G, self.P, min_common_weight=0.1)["excluded"]["A"], "FAIL")

    def test_factor_catalogue_and_weights(self):
        self.assertEqual(len(F.FACTORS), 20); self.assertEqual(len({f.key for f in F.FACTORS}), 20); self.assertAlmostEqual(sum(F.example_weights().values()), 1.0)
        self.assertTrue(all(f.status in F.IMPL and f.units and f.method and f.missing_policy and f.uncertainty and f.resolution and f.validity for f in F.FACTORS))
        w = F.example_weights(); w["slope"] += .1
        with self.assertRaises(ValueError): F.normalise_weights(w)
        self.assertAlmostEqual(sum(F.normalise_weights(w, "mission rationale").values()), 1.0)


class TestMesh(unittest.TestCase):
    def test_obj_ply_scale_and_nan(self):
        z = np.random.rand(20, 30).astype("float32"); z[5, 5] = np.nan; v, f, c = meshio.dem_mesh(z, np.full((20, 30), 10.0), np.full((20, 30), 10.0), 2.0)
        self.assertAlmostEqual(float(v[:, 0].max() - v[:, 0].min()), 290.0); self.assertAlmostEqual(float(v[:, 2].max()), float(np.nanmax(z) * 2), places=4)
        self.assertEqual(len(f), 2 * (19 * 29 - 4)); d = tmpdir(); meshio.write_obj(d + "/m.obj", v, f, {"crs": "x"}); meshio.write_ply(d + "/m.ply", v, f, None, {"crs": "x"})
        self.assertEqual(sum(1 for l in open(d + "/m.obj") if l.startswith("v ")), len(v)); self.assertIn("element face %d" % len(f), open(d + "/m.ply").read())
