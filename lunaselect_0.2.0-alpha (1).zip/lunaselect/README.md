# LunaSelect 0.2.0-alpha

Offline-first lunar landing-site assessment (DEM terrain, Sun/Earth visibility with terrain horizon, hard gates, weighted preferences, sensitivity, reports, 3D mesh export). **Independent research software: not developed, approved, certified or endorsed by NASA or JPL. No score is a probability of landing success or a safety certification.** Bundled demo data are SYNTHETIC.

## Install
**Linux/macOS:** `python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt && pip install -e .`
**Windows (PowerShell):** `py -m venv .venv; .\.venv\Scripts\Activate.ps1; pip install -r requirements.txt; pip install -e .`  (Windows not tested by the author)
**Google Colab:** open notebooks/LunaSelect_Colab.ipynb (not executed in Colab by the author).
Core needs only numpy, scipy, tifffile, pillow, pyyaml, reportlab, matplotlib; the console adds streamlit + plotly.

## Run
`python -m lunaselect demo ./out` · tests: `python -m unittest discover -s tests -v` (35 tests) · console: `streamlit run src/lunaselect/ui/app.py`

## Read next
docs/MILESTONES.md (what works, what does not) · docs/ARCHITECTURE.md (audit, deviations) · docs/METHODOLOGY.md · docs/DATA_DICTIONARY.md · docs/VALIDATION_REPORT.md · docs/USER_GUIDE.md · examples/site11_SYNTHETIC_demo/
