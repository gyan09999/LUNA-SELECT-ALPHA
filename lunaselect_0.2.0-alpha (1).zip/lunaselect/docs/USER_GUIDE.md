# User guide (CLI first; console optional)

1. `python -m lunaselect demo ./out` runs the SYNTHETIC Site 11 demonstration (inputs, workspace, reports, OBJ/PLY).
2. Own data: `python -m lunaselect init WS --project ID --site "Site 11"`; `ingest WS file.tif --data-class calibrated`; `datasets WS`.
3. If a dataset is UNCERTAIN, confirm: `confirm WS ds_xxx dem --user you --note "label checked"`.
4. Write a YAML config (see configs/site11_demo_config.yaml: gates with your mission limits, preferences with best/worst, environment window) then `run WS ds_xxx --config cfg.yaml`.
5. `report WS` (JSON, CSV, PDF); `mesh WS ds_xxx --format obj|ply|glb --vexag 2 --stride 2`; `verify WS` (integrity).
6. Console: `pip install streamlit plotly` then `streamlit run src/lunaselect/ui/app.py` (modules: Mission Overview ... Report Generator).
Interpretation: PASS means no configured hard gate failed on the supplied data; it is not a safety certification. Check score coverage and NOT_ASSESSED factors first.
