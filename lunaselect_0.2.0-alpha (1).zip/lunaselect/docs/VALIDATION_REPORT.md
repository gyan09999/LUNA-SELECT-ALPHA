# Verification report (software tests, NOT mission validation)

Run: `python -m unittest discover -s tests -v` on Python 3.12, numpy/scipy/tifffile as in requirements-lock-sandbox.txt. Result: **35 tests, all passed**. Passing these tests shows the code behaves as specified on synthetic and analytic cases. It does not validate any landing-site assessment against real lunar data.

## What is checked against independent truth
- GeoTIFF georeferencing agrees with tifffile's independent parser; projection round-trips; stereographic scale factor equals 2k0/(1+cos c).
- Slope of planes of 1/10/30 deg recovered to <0.001 deg; cone surface recovered to <0.05 deg only with scale correction (uncorrected error >0.1 deg at ~350 km range).
- Shadow length behind a 20 m ridge at 5 deg Sun elevation matches h/tan(el) to <1.5 px; flat-DEM illumination fraction matches the smooth-sphere ephemeris.
- Curvature of a paraboloid (4a), plane-residual roughness (0 for planes, sigma for white noise), local relief of a ramp.
- Crater candidates: 3 of 3 synthetic craters found at exact pixel; diameters within 20% (observed up to 15%), depths within 10%; ridge flanks rejected as very_low; noise-only DEM yields 0.
- Ephemeris: Sun elevation at four Apollo landing epochs matches the model's regression values (10.70, 5.15, 12.02, 13.34 deg) and approximate reference values recalled from mission records within 0.6 deg (those references were NOT independently re-verified); Meeus libration example within 0.05-0.1 deg.
- Reproducibility: identical derived-product SHA-256 and score on two independent runs.

## Defects found by these tests during development (fixed)
1. Slope was produced at NoData pixels (Horn kernel ignores the centre pixel): now NaN.
2. Coverage was computed against valid pixels only, letting a 62%-empty DEM pass a coverage gate: now measured against the whole raster extent.
3. NaN poisoning of running-sum filters made roughness all-NaN: windows touching NoData/edges are now masked explicitly.
4. LoG scale under-estimates crater diameter by ~26% (bowl) to ~0% (flat floor): calibrated, documented, `scale_diameter_m` retained.
5. Ridge flanks produced crater false positives: rim-circularity criterion added.

## Known limitations of the verification
No real lunar datasets, no PDS/ISIS products, no external reference implementations (GDAL/SPICE) available offline. Streamlit UI checked only with a stub. Crater detector calibrated on idealised synthetic bowls. Ephemeris is a low-precision analytical model (no SPICE).

## Test inventory
- test_flat_dem_matches_smooth_sphere
- test_incidence_on_flat_surface
- test_incomplete_flag_at_dem_edge
- test_shadow_length_analytic
- test_cases
- test_obj_ply_scale_and_nan
- test_comparability_and_stability
- test_factor_catalogue_and_weights
- test_gate_statuses_and_no_compensation
- test_missing_data_never_scored_favourably
- test_failures_and_warnings
- test_grid_compat
- test_apollo_sun_elevation
- test_meeus_libration_and_subsolar
- test_crs_classification
- test_pixel_is_point_and_rotation
- test_projection_roundtrip_and_pole
- test_resample_cross_crs_and_oversampling_flag
- test_roundtrip_and_independent_parser
- test_stereographic_scale_factor
- test_cone_needs_scale_correction
- test_crater_detection_vs_truth
- test_hillshade_aspect_curvature_relief_roughness
- test_nodata_not_filled
- test_plane_slope_exact
- test_insufficient_coverage_blocks_pass
- test_products_and_evaluation
- test_reports_and_exports
- test_reproducibility
- test_corrupt_truncated_and_foreign_files
- test_immutable_originals_identity_and_dedupe
- test_large_raster_ingest_and_slope
- test_type_confirmation_history
- test_unknown_crs_slope_only_and_earth_crs_refused
- test_all_pages_run
