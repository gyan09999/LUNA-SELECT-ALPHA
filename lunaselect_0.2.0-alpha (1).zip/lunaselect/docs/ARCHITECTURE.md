# Architecture and codebase audit

## Audit (what was actually inspected)
No LunaSelect 0.2.0 repository, Colab launcher, Site 11 slope TIFF or existing tests were available in this session: only three screenshots (a 3D lunar-terrain concept with a time slider, layer list and a Three.js/Cesium/SPICE suggestion) and the task text were provided. The only code present at the start of this turn was my own 0.1.0 prototype (502 lines, 7 modules: GeoTIFF I/O, identification, slope, quick-look, constraints, factors) with no tests, workspace, validation, environment model, scoring, reports or UI. Nothing from your 0.2.0 could be preserved or audited. **Please upload the 0.2.0 repo and the Site 11 slope TIFF**; the ingestion layer already accepts a slope TIFF, keeps its project identity (Site 11) regardless of a `Site01` filename, and treats it as a derived product (it cannot produce 3D or terrain analysis without a DEM).

## Deviations from the specified stack (offline sandbox, no package installs)
Used: NumPy, SciPy, tifffile, Pillow, PyYAML, ReportLab, Matplotlib. Not installable here: Rasterio/GDAL, GeoPandas, Shapely, PyProj, xarray, PyVista, Plotly, Streamlit. Consequently the GIS core is a native GeoTIFF/CRS engine (north-up, geographic or polar stereographic on a sphere); the Streamlit/Plotly console is written but was only exercised with a stub; vector, NetCDF/HDF5 and PDS/ISIS readers are declared adapters with honest status. A GDAL/rasterio backend can replace `geo.py` behind the same `Raster` interface.

## Modules (src/lunaselect)
geo (I/O, CRS, projection, resampling) · identify · validate · workspace (immutable originals, manifests, derived, log) · terrain · environment (+ ephemeris) · factors (catalogue) · scoring (gates, WLC, comparability, sensitivity) · pipeline · report · meshio · quicklook · cli · ui/app.py. No network access anywhere. Workspace layout: project.yaml, originals/ (read-only), derived/, manifests/, exports/, reports/, logs/events.jsonl.

## Prioritised implementation sequence followed
1 ephemeris + CRS/projection + immutable ingestion with identity/provenance -> 2 validation + terrain metrics -> 3 terrain-horizon illumination/Earth visibility -> 4 gates/scoring/sensitivity -> 5 end-to-end synthetic Site 11 pipeline + reports + mesh -> 6 console + docs. Pending: real-data validation, footprint-level zones, thermal/radiation/relay/resource models, adapters.

## Mapping of the concept screenshots to this build
Elevation, slope/hazard, sunlight/shadow and Sun/Earth-direction layers exist as computed products (shadows from DEM + ephemeris, not a texture on a sphere). The 3D explorer meshes the DEM; wiring the time slider to live shadow lighting in 3D is NOT yet implemented. Three.js/Cesium/SPICE were not used (offline Python stack; SPICE kernels unavailable).
