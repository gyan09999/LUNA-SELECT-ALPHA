# Data dictionary

## 20-factor catalogue (proposal requiring mission-specific engineering approval)

| # | key | factor | group | units | preference | calibration | implementation | resolution | validity | uncertainty |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | elevation | Elevation / DEM | terrain | m | context | calibrated product required | implemented_tested | native DEM pixel (m); static | -12000..12000 m (lunar range) | vertical/horizontal error from product metadata |
| 2 | slope | Slope | terrain | deg | lower_better | derived | implemented_tested | 2x pixel spacing (baseline-dependent) | 0..90 deg | baseline-dependent; DEM error propagates ~ sqrt(2)*sigma_z/baseline |
| 3 | roughness | Surface roughness | terrain | m RMS height | lower_better | derived | implemented_tested | window size (m), reported with value | >= 0 m | scale-dependent: report window |
| 4 | crater_density | Crater density | terrain | candidates / km2 | lower_better | derived (candidates require human review) | partially_implemented | scale range (m) of detection | >= 0 | diameter +/-35% (morphology-dependent); completeness unknown |
| 5 | rock_abundance | Rock / boulder abundance | terrain | fraction or per km2 | lower_better | calibrated/derived product required | ingest_only | per product | 0..1 | from product |
| 6 | local_relief | Local relief | terrain | m | lower_better | derived | implemented_tested | window size (m) | >= 0 m | DEM vertical error |
| 7 | illumination_duration | Illumination duration | environment | fraction of time / h | higher_better | modelled | implemented_tested | DEM pixel; time step set by user | 0..1 | ephemeris ~0.1 deg; DEM edge pixels flagged incomplete |
| 8 | solar_incidence | Solar incidence angle | environment | deg | target_range | modelled | implemented_tested | DEM pixel; instant | 0..90 deg (lit) | ephemeris + slope baseline |
| 9 | max_temperature | Maximum surface temperature | environment | K | lower_better | calibrated product required | ingest_only | per product; temporal sampling per product | 20..420 K | from product |
| 10 | min_temperature | Minimum surface temperature | environment | K | higher_better | calibrated product required | ingest_only | per product | 20..420 K | from product |
| 11 | thermal_variation | Thermal variation | environment | K | lower_better | derived | not_started | per product | >= 0 K | propagated from inputs |
| 12 | radiation | Radiation environment | environment | mSv/day or dose-rate | lower_better | calibrated/validated model required | ingest_only | per product | >= 0 | from product |
| 13 | micrometeoroid | Micrometeoroid flux | environment | impacts / m2 / yr | lower_better | validated model required | ingest_only | per product | >= 0 | from model |
| 14 | earth_visibility | Earth visibility | communications | fraction of time / h | higher_better | modelled | implemented_tested | DEM pixel; time step set by user | 0..1 | ephemeris + DEM horizon completeness |
| 15 | relay_visibility | Relay communication visibility | communications | fraction of time / h | higher_better | mission input required | not_started | mission-defined | 0..1 | orbit-determination error |
| 16 | water_ice | Water-ice prospectivity | resources | indicator (product-specific) | higher_better | calibrated product required | ingest_only | per product (often km-scale) | per product | from product |
| 17 | hydrogen | Hydrogen abundance | resources | wt% H (or equivalent) | higher_better | calibrated product required | ingest_only | per product (often ~10 km) | per product | from product |
| 18 | volatiles | Volatile abundance | resources | product-specific | higher_better | calibrated product required | ingest_only | per product | per product | from product |
| 19 | regolith | Regolith composition | resources | product-specific | target_range | calibrated product required | ingest_only | per product | per product | from product |
| 20 | resource_access | Resource accessibility | resources | h / m | higher_better | mission input required | not_started | mission-defined | n/a | propagated |

Common to all factors. Formats: GeoTIFF/COG (native reader); NetCDF/HDF5, PDS3/PDS4/ISIS via adapters (not yet implemented). Missing-data policy: No default score. No data -> NOT ASSESSED; coverage below the configured minimum -> INSUFFICIENT DATA.

## Dataset manifest (manifests/<id>.json)
id (ds_<sha12> original, dv_<sha12> derived) · kind · original_filename · sha256 · size_bytes · stored_path (read-only) · status (READY | UNREADABLE | STORED_NOT_PARSED) ·
site{project_site_id, filename_hint, hint_agrees, note} · data_class (raw | calibrated | derived | simulated | unspecified: never assumed) · synthetic ·
dataset_type{suggested, identification_status IDENTIFIED/UNCERTAIN/UNKNOWN, candidates[evidence_points], confirmed, confirmed_by} · crs · native_pixel_size · ground_spacing ·
bounds_native · coverage_lonlat · units · nodata · instrument_source · acquisition_date · provenance · quality{status, checks[V01..V16]} · processing_history[{step, params, inputs[{id,sha256}], output_sha256}].

## Quality check ids
V01 readable · V02 georeferenced · V03 rotation-free · V04 pixel size · V05 CRS defined · V06 CRS body is Moon · V07 matches project sphere · V08 projection supported · V09 linear unit · V10 valid pixels · V11 NoData declared / sentinel values · V12 robust outliers · V13 constant raster · V14 plausible range for type · V15 single band · V16 study-area overlap.
Statuses: PASS, WARN, FAIL, INDETERMINATE, NOT_APPLICABLE.

## Decision statuses
PASS, FAIL, CONDITIONAL, INSUFFICIENT_DATA, NOT_ASSESSED. Evidence classes: declared, metadata, units, values, filename (weakest).
