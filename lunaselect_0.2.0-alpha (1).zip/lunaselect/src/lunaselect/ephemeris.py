"""Moon/Sun/Earth geometry for lunar surface sites (low-precision analytical model, vectorised).

Truncated Meeus (Astronomical Algorithms 2nd ed., ch. 25, 47, 53) series: lunar longitude/latitude/distance,
optical + physical libration, sub-Earth and sub-solar selenographic points. Moon = smooth sphere (R=1737.4 km).
Expected accuracy ~0.05-0.1 deg in elevation (see tests/test_ephemeris.py); no terrain, no light-time/aberration refinements.
"""
from __future__ import annotations
import numpy as np

RM_KM = 1737.4
_s = lambda x: np.sin(np.radians(x))
_c = lambda x: np.cos(np.radians(x))
n180 = lambda x: (np.asarray(x, float) % 360 + 540) % 360 - 180


def unix_to_jd(t):
    return np.asarray(t, float) / 86400.0 + 2440587.5


def sub_points(unix_s):
    """dict(earth_lon, earth_lat, sun_lon, sun_lat, dist_km, parallax) for UTC unix seconds (scalar or array)."""
    d = unix_to_jd(unix_s) - 2451545.0
    T = d / 36525.0
    Lp = 218.3164477 + 481267.88123421 * T; D = 297.8501921 + 445267.1114034 * T
    M = 357.5291092 + 35999.0502909 * T; Mp = 134.9633964 + 477198.8675055 * T
    F = 93.272095 + 483202.0175233 * T; Om = 125.0445479 - 1934.1362891 * T
    K1 = 119.75 + 131.849 * T; K2 = 72.56 + 20.186 * T
    s, c = _s, _c
    lon = (Lp + 6.288774 * s(Mp) + 1.274027 * s(2 * D - Mp) + 0.658314 * s(2 * D) + 0.213618 * s(2 * Mp) - 0.185116 * s(M)
           - 0.114332 * s(2 * F) + 0.058793 * s(2 * D - 2 * Mp) + 0.057066 * s(2 * D - M - Mp) + 0.053322 * s(2 * D + Mp)
           + 0.045758 * s(2 * D - M) - 0.040923 * s(M - Mp) - 0.03472 * s(D) - 0.030383 * s(M + Mp) + 0.015327 * s(2 * D - 2 * F)
           - 0.012528 * s(Mp + 2 * F) + 0.01098 * s(Mp - 2 * F) + 0.003958 * s(K1) + 0.001962 * s(Lp - F))
    lat = (5.128122 * s(F) + 0.280602 * s(Mp + F) + 0.277693 * s(Mp - F) + 0.173237 * s(2 * D - F) + 0.055413 * s(2 * D - Mp + F)
           + 0.046271 * s(2 * D - Mp - F) + 0.032573 * s(2 * D + F) + 0.017198 * s(2 * Mp + F) + 0.009266 * s(2 * D + Mp - F)
           + 0.008823 * s(2 * Mp - F) + 0.008247 * s(2 * D - M - F))
    dist = (385000.56 - 20905.355 * c(Mp) - 3699.111 * c(2 * D - Mp) - 2955.968 * c(2 * D) - 569.925 * c(2 * Mp) + 48.888 * c(M)
            - 3.149 * c(2 * F) + 246.158 * c(2 * D - 2 * Mp) - 152.138 * c(2 * D - M - Mp) - 170.733 * c(2 * D + Mp)
            - 204.586 * c(2 * D - M) - 129.62 * c(M - Mp) + 108.743 * c(D) + 104.755 * c(M + Mp))
    g = 357.528 + 0.9856003 * d
    lam0 = 280.46 + 0.9856474 * d + 1.915 * s(g) + 0.02 * s(2 * g)
    dA = (1.00014 - 0.01671 * c(g) - 0.00014 * c(2 * g)) * 149597870.7
    hx = dist * c(lat) * c(lon) - dA * c(lam0); hy = dist * c(lat) * s(lon) - dA * s(lam0); hz = dist * s(lat)
    lh = np.degrees(np.arctan2(hy, hx)); bh = np.degrees(np.arctan2(hz, np.hypot(hx, hy)))
    pr = (-0.02752 * c(Mp) - 0.02245 * s(F) + 0.00684 * c(Mp - 2 * F) - 0.00293 * c(2 * F) - 0.00085 * c(2 * F - 2 * D)
          - 0.00054 * c(Mp - 2 * D))
    sg = (-0.02816 * s(Mp) + 0.02244 * c(F) - 0.00682 * s(Mp - 2 * F) - 0.00279 * s(2 * F) - 0.00083 * s(2 * F - 2 * D)
          + 0.00069 * s(Mp - 2 * D))
    ta = (0.0252 * s(M) + 0.00473 * s(2 * Mp - 2 * F) - 0.00467 * s(Mp) + 0.00396 * s(K1) + 0.00276 * s(2 * Mp - 2 * D)
          + 0.00196 * s(Om) - 0.00183 * c(Mp - F) + 0.00115 * s(Mp - 2 * D) - 0.00096 * s(Mp - D) + 0.00023 * s(K2))
    I = 1.54242

    def sub(lam, bt):
        W = lam - Om
        A = np.degrees(np.arctan2(s(W) * c(bt) * c(I) - s(bt) * s(I), c(W) * c(bt)))
        bp = np.degrees(np.arcsin(-s(W) * c(bt) * s(I) - s(bt) * c(I)))
        return n180(A - F - ta + (pr * c(A) + sg * s(A)) * np.tan(np.radians(bp))), bp + sg * c(A) - pr * s(A)

    el, eb = sub(lon, lat); sl, sb = sub(lh, bh)
    return dict(earth_lon=el, earth_lat=eb, sun_lon=sl, sun_lat=sb, dist_km=dist, parallax=RM_KM / (dist / 1.0))


def look(lat, lon, b, l, parallax=0.0):
    """Elevation and azimuth (deg, azimuth clockwise from north) of the body at sub-point (b,l) seen from (lat,lon).
    Earth parallax is applied to elevation (not azimuth; effect < 0.3 deg). Arrays broadcast."""
    la, dl, bb = np.radians(lat), np.radians(np.asarray(l) - lon), np.radians(b)
    cg = np.sin(la) * np.sin(bb) + np.cos(la) * np.cos(bb) * np.cos(dl)
    q = (cg - parallax) / np.sqrt(1 + parallax ** 2 - 2 * parallax * cg) if np.any(parallax) else cg
    el = np.degrees(np.arcsin(np.clip(q, -1, 1)))
    az = np.degrees(np.arctan2(np.cos(bb) * np.sin(dl), np.cos(la) * np.sin(bb) - np.sin(la) * np.cos(bb) * np.cos(dl))) % 360
    return el, az


def sun_look(lat, lon, unix_s):
    p = sub_points(unix_s); return look(lat, lon, p["sun_lat"], p["sun_lon"])


def earth_look(lat, lon, unix_s):
    p = sub_points(unix_s); return look(lat, lon, p["earth_lat"], p["earth_lon"], p["parallax"] * 1.0)
