"""Evidence-based dataset identification. Filename alone is never sufficient.

Evidence classes: declared (explicit LUNASELECT_TYPE tag), metadata (descriptions/tags), units, values, filename.
Scores are EVIDENCE POINTS, not probabilities. A value-range violation vetoes a candidate.
When evidence is insufficient or ambiguous the dataset must be confirmed by the user."""
from __future__ import annotations
import re
import numpy as np

INF = float("inf")
# key: (label, accepted units (normalised), plausible physical range, metadata/filename tokens)
TYPES = {
    "dem": ("Elevation (DEM)", ("m", "meter", "metre", "meters", "metres"), (-12000, 12000), ("dem", "ldem", "elevation", "topograph", "dtm", "height")),
    "slope": ("Surface slope", ("deg", "degree", "degrees", "°"), (0, 90), ("slope",)),
    "roughness": ("Surface roughness", ("m", "meter", "metre"), (0, 2000), ("rough", "rms")),
    "boulders": ("Boulder density", ("per km2", "1/km2", "count/km2", "boulders/km2"), (0, INF), ("boulder",)),
    "craters": ("Crater / pit density", ("per km2", "1/km2", "count/km2", "craters/km2"), (0, INF), ("crater", "pit")),
    "rock_abundance": ("Rock abundance", ("fraction", "1"), (0, 1), ("rockabund", "rock_abund", "rock abund")),
    "regolith": ("Regolith / thermal inertia", ("tiu", "j m-2 k-1 s-1/2"), (0, 2000), ("regolith", "bearing", "thermalinertia", "thermal inertia")),
    "illumination": ("Solar illumination", ("fraction", "1", "%", "percent"), (0, 100), ("illum", "sunlit", "insolation")),
    "temperature": ("Surface temperature", ("k", "kelvin"), (20, 420), ("temp", "tmax", "tmin", "diviner")),
    "earth_visibility": ("Earth visibility", ("fraction", "1", "%", "percent"), (0, 100), ("earthvis", "earth_vis", "comm", "visibility")),
    "radiation": ("Radiation", ("msv/day", "gy", "msv"), (0, INF), ("radiation", "dose", "crater")),
    "ice_indicator": ("Water-ice indicator", ("fraction", "1", "wt%"), (0, 100), ("ice", "water", "lamp", "m3")),
    "hydrogen": ("Hydrogen / volatiles", ("wt%", "wt% h2o", "cps"), (0, INF), ("hydrogen", "lend", "volatile")),
    "mineralogy": ("Mineralogy", ("index", "1"), (-INF, INF), ("mineral", "m3", "lithology")),
    "gravity": ("Gravity / subsurface", ("mgal",), (-INF, INF), ("gravity", "grail", "bouguer")),
    "radar": ("Radar / subsurface", ("db", "1"), (-INF, INF), ("radar", "mini-rf", "cpr")),
}
W = {"declared": 10, "metadata": 3, "units": 2, "values": 1, "filename": 1}


def _norm(u):
    return re.sub(r"\s+", " ", (u or "").strip().lower())


def identify(filename: str, units, description, tags: dict, values: np.ndarray | None) -> dict:
    fname = re.sub(r"[^a-z0-9 ]+", " ", filename.lower().rsplit(".", 1)[0])
    meta_text = " ".join([_norm(description)] + [f"{k} {v}".lower() for k, v in (tags or {}).items() if k != "LUNASELECT_TYPE"])
    declared = (tags or {}).get("LUNASELECT_TYPE", "").strip().lower()
    lo = hi = None
    if values is not None and values.size:
        lo, hi = float(np.percentile(values, 0.1)), float(np.percentile(values, 99.9))
    cands = []
    for key, (label, uns, (rlo, rhi), toks) in TYPES.items():
        ev, veto = [], None
        if declared == key:
            ev.append(("declared", "type declared in file metadata (LUNASELECT_TYPE)"))
        if any(t in meta_text for t in toks):
            ev.append(("metadata", "descriptor/tag mentions " + "/".join(t for t in toks if t in meta_text)))
        if _norm(units) and _norm(units) in uns:
            ev.append(("units", f"unit '{units}' is accepted for this type"))
        if any(t in fname for t in toks):
            ev.append(("filename", "filename token (weak evidence)"))
        if lo is not None:
            tol = 0.01 * (rhi - rlo) if np.isfinite(rhi - rlo) else 0.0
            if lo < rlo - tol or hi > rhi + tol:
                veto = f"values [{lo:.4g}, {hi:.4g}] outside plausible range [{rlo}, {rhi}]"
            else:
                ev.append(("values", f"values [{lo:.4g}, {hi:.4g}] are within the plausible range"))
        cands.append(dict(type=key, label=label, evidence_points=0 if veto else sum(W[c] for c, _ in ev),
                          evidence=[dict(cls=c, detail=d) for c, d in ev], vetoed=bool(veto), veto_reason=veto))
    cands.sort(key=lambda c: -c["evidence_points"])
    top, second = cands[0], cands[1]
    non_file = {e["cls"] for e in top["evidence"]} - {"filename"}
    if top["evidence_points"] == 0:
        status, why = "UNKNOWN", "no usable evidence"
    elif "declared" in non_file:
        status, why = "IDENTIFIED", "declared in file metadata and consistent with the data values"
    elif len(non_file) >= 2 and top["evidence_points"] - second["evidence_points"] >= 2:
        status, why = "IDENTIFIED", "two or more independent non-filename evidence classes, clear margin over runner-up"
    else:
        status, why = "UNCERTAIN", "evidence is insufficient or ambiguous between types: analyst confirmation required"
    return dict(status=status, suggested_type=top["type"] if status != "UNKNOWN" else None, reason=why,
                needs_user_confirmation=status != "IDENTIFIED", candidates=cands[:4],
                note="evidence_points are not probabilities")
