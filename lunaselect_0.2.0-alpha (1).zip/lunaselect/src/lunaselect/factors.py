"""Proposed 20-factor catalogue (requires mission-specific engineering approval; NOT an established standard).
Each factor documents: source requirements, formats, units, calibration status, processing method, resolution,
validity range, uncertainty, preference direction, missing-data policy, and implementation status (honest)."""
from __future__ import annotations
from dataclasses import dataclass, asdict

FMT = "GeoTIFF/COG (native reader); NetCDF/HDF5, PDS3/PDS4/ISIS via adapters (not yet implemented)"
MISS = "No default score. No data -> NOT ASSESSED; coverage below the configured minimum -> INSUFFICIENT DATA."
IMPL = ("implemented_tested", "partially_implemented", "ingest_only", "not_started", "blocked")


@dataclass(frozen=True)
class Factor:
    id: int; key: str; name: str; group: str; units: str; direction: str      # lower_better | higher_better | target_range | context
    source: str; calibration: str; method: str; resolution: str; validity: str; uncertainty: str; status: str
    dataset_types: tuple = (); formats: str = FMT; missing_policy: str = MISS


F = Factor
FACTORS = [
    F(1, "elevation", "Elevation / DEM", "terrain", "m", "context", "Calibrated DEM (e.g. laser altimetry or stereo DTM) with product label", "calibrated product required",
      "validation, summary statistics, hillshade, 3D mesh", "native DEM pixel (m); static", "-12000..12000 m (lunar range)", "vertical/horizontal error from product metadata", "implemented_tested", ("dem",)),
    F(2, "slope", "Slope", "terrain", "deg", "lower_better", "DEM, or a validated slope product", "derived",
      "Horn 3x3 kernel, ground-spacing aware (stereographic scale factor), configurable baseline; NoData never filled", "2x pixel spacing (baseline-dependent)", "0..90 deg",
      "baseline-dependent; DEM error propagates ~ sqrt(2)*sigma_z/baseline", "implemented_tested", ("dem", "slope")),
    F(3, "roughness", "Surface roughness", "terrain", "m RMS height", "lower_better", "DEM", "derived",
      "RMS residual about local least-squares plane in a metre-defined window", "window size (m), reported with value", ">= 0 m", "scale-dependent: report window", "implemented_tested", ("dem", "roughness")),
    F(4, "crater_density", "Crater density", "terrain", "candidates / km2", "lower_better", "DEM (or validated crater catalogue)", "derived (candidates require human review)",
      "scale-space LoG candidate detection, calibrated on synthetic craters only", "scale range (m) of detection", ">= 0", "diameter +/-35% (morphology-dependent); completeness unknown", "partially_implemented", ("dem", "craters")),
    F(5, "rock_abundance", "Rock / boulder abundance", "terrain", "fraction or per km2", "lower_better", "Validated rock-abundance product or boulder catalogue from suitable imagery", "calibrated/derived product required",
      "ingest only; never inferred from DEM roughness", "per product", "0..1", "from product", "ingest_only", ("rock_abundance", "boulders")),
    F(6, "local_relief", "Local relief", "terrain", "m", "lower_better", "DEM", "derived", "max-min in a metre-defined window (NaN if window touches NoData)", "window size (m)", ">= 0 m", "DEM vertical error", "implemented_tested", ("dem",)),
    F(7, "illumination_duration", "Illumination duration", "environment", "fraction of time / h", "higher_better", "DEM + site/time inputs (ephemeris)", "modelled",
      "terrain-horizon ray marching with analytical ephemeris over a user time window", "DEM pixel; time step set by user", "0..1", "ephemeris ~0.1 deg; DEM edge pixels flagged incomplete", "implemented_tested", ("dem", "illumination")),
    F(8, "solar_incidence", "Solar incidence angle", "environment", "deg", "target_range", "DEM + ephemeris", "modelled", "angle between surface normal and Sun direction at a chosen UTC time", "DEM pixel; instant", "0..90 deg (lit)", "ephemeris + slope baseline", "implemented_tested", ("dem",)),
    F(9, "max_temperature", "Maximum surface temperature", "environment", "K", "lower_better", "Calibrated thermal product (e.g. radiometer-derived) with date/season", "calibrated product required",
      "ingest only; no thermal model implemented", "per product; temporal sampling per product", "20..420 K", "from product", "ingest_only", ("temperature",)),
    F(10, "min_temperature", "Minimum surface temperature", "environment", "K", "higher_better", "Calibrated thermal product", "calibrated product required", "ingest only", "per product", "20..420 K", "from product", "ingest_only", ("temperature",)),
    F(11, "thermal_variation", "Thermal variation", "environment", "K", "lower_better", "Max and min temperature products on the same grid", "derived", "max - min (requires factors 9 and 10)", "per product", ">= 0 K", "propagated from inputs", "not_started", ("temperature",)),
    F(12, "radiation", "Radiation environment", "environment", "mSv/day or dose-rate", "lower_better", "Traceable dataset or validated model output", "calibrated/validated model required", "ingest only", "per product", ">= 0", "from product", "ingest_only", ("radiation",)),
    F(13, "micrometeoroid", "Micrometeoroid flux", "environment", "impacts / m2 / yr", "lower_better", "Traceable flux model output with stated size threshold", "validated model required", "ingest only", "per product", ">= 0", "from model", "ingest_only", ()),
    F(14, "earth_visibility", "Earth visibility", "communications", "fraction of time / h", "higher_better", "DEM + site/time inputs", "modelled",
      "terrain-horizon ray marching toward the Earth direction (parallax included)", "DEM pixel; time step set by user", "0..1", "ephemeris + DEM horizon completeness", "implemented_tested", ("dem", "earth_visibility")),
    F(15, "relay_visibility", "Relay communication visibility", "communications", "fraction of time / h", "higher_better", "Relay orbit ephemeris (e.g. SPK/TLE-like) and antenna constraints", "mission input required",
      "adapter for relay ephemeris not built", "mission-defined", "0..1", "orbit-determination error", "not_started", ()),
    F(16, "water_ice", "Water-ice prospectivity", "resources", "indicator (product-specific)", "higher_better", "Calibrated instrument observations with uncertainty", "calibrated product required",
      "ingest only; never inferred from terrain proxies", "per product (often km-scale)", "per product", "from product", "ingest_only", ("ice_indicator",)),
    F(17, "hydrogen", "Hydrogen abundance", "resources", "wt% H (or equivalent)", "higher_better", "Calibrated neutron/gamma/IR products", "calibrated product required", "ingest only", "per product (often ~10 km)", "per product", "from product", "ingest_only", ("hydrogen",)),
    F(18, "volatiles", "Volatile abundance", "resources", "product-specific", "higher_better", "Calibrated products", "calibrated product required", "ingest only", "per product", "per product", "from product", "ingest_only", ("hydrogen", "ice_indicator")),
    F(19, "regolith", "Regolith composition", "resources", "product-specific", "target_range", "Calibrated spectral/compositional products", "calibrated product required", "ingest only", "per product", "per product", "from product", "ingest_only", ("mineralogy", "regolith")),
    F(20, "resource_access", "Resource accessibility", "resources", "h / m", "higher_better", "Resource layer + terrain + equipment and operational constraints", "mission input required", "not implemented", "mission-defined", "n/a", "propagated", "not_started", ()),
]
BY_KEY = {f.key: f for f in FACTORS}


def example_weights():
    """PLACEHOLDER equal weights (5% each). Not engineering-approved: replace via configs/weights.example.yaml."""
    return {f.key: 1.0 / len(FACTORS) for f in FACTORS}


def normalise_weights(weights: dict, justification: str | None = None, reference: dict | None = None) -> dict:
    keys = {f.key for f in FACTORS}
    if not set(weights) <= keys:
        raise ValueError(f"unknown factor(s): {sorted(set(weights) - keys)}")
    if any(w < 0 for w in weights.values()) or sum(weights.values()) <= 0:
        raise ValueError("weights must be non-negative with a positive sum")
    ref = reference or example_weights()
    t = float(sum(weights.values())); n = {k: w / t for k, w in weights.items()}
    if any(abs(n.get(k, 0) - ref.get(k, 0) / sum(ref.values())) > 1e-9 for k in keys) and not (justification and justification.strip()):
        raise ValueError("a written justification is required when weights differ from the reference set")
    return n


def as_dicts():
    return [asdict(f) for f in FACTORS]
