"""LunaSelect: independent research software for lunar landing-site assessment.
Not developed, approved, certified or endorsed by NASA or JPL."""
__version__ = "0.2.0-alpha"
