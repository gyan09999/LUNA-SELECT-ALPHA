"""PNG quick-looks (preview only; originals and analysis rasters are unaffected)."""
from __future__ import annotations
import numpy as np
from PIL import Image

_STOPS = np.array([[68, 1, 84], [59, 82, 139], [33, 144, 141], [93, 201, 99], [253, 231, 37]], float)


def _cmap(t):
    t = np.clip(t, 0, 1) * (len(_STOPS) - 1); i = np.minimum(t.astype(int), len(_STOPS) - 2); f = (t - i)[..., None]
    return (_STOPS[i] * (1 - f) + _STOPS[i + 1] * f).astype(np.uint8)


def render(path, arr, kind, vmin=None, vmax=None, max_px=1600):
    """kind: dem | slope | hillshade. NaN -> transparent. Returns dict with the colour scale used."""
    a = np.asarray(arr, np.float32); ok = np.isfinite(a)
    if kind == "hillshade":
        lo, hi, rgb = 0.0, 1.0, np.repeat((np.nan_to_num(a) * 255).astype(np.uint8)[..., None], 3, 2)
    else:
        lo = vmin if vmin is not None else (0.0 if kind == "slope" else float(np.nanpercentile(a, 2)) if ok.any() else 0.0)
        hi = vmax if vmax is not None else (30.0 if kind == "slope" else float(np.nanpercentile(a, 98)) if ok.any() else 1.0)
        rgb = _cmap((np.nan_to_num(a) - lo) / ((hi - lo) or 1.0))
    img = Image.fromarray(np.dstack([rgb, np.where(ok, 255, 0).astype(np.uint8)]), "RGBA")
    scale = max(img.size) / max_px
    if scale > 1:
        img = img.resize((int(img.width / scale), int(img.height / scale)), Image.NEAREST)
    img.save(path)
    return dict(kind=kind, vmin=lo, vmax=hi, width=img.width, height=img.height, downscaled=scale > 1,
                note="slope uses a fixed 0-30 deg colour scale; dem uses 2-98 percentile stretch" if kind != "hillshade" else "azimuth 315, altitude 45")
