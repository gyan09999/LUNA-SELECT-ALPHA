"""Raster validation: every dataset gets an itemised, machine-readable quality report. Nothing is repaired silently."""
from __future__ import annotations
import math
import numpy as np
from .geo import Raster, ground_spacing, lonlat_bbox, UnsupportedError, MOON_R
from .identify import TYPES

FILL_CANDIDATES = (-9999.0, -32768.0, -999.0, 65535.0, 9999.0, -3.4028234663852886e38, 1e20, -1e20)
PASS, WARN, FAIL, INDET, NA = "PASS", "WARN", "FAIL", "INDETERMINATE", "NOT_APPLICABLE"


def _chk(i, name, status, msg, **d):
    return dict(id=i, name=name, status=status, message=msg, details=d)


def run_checks(r: Raster | None, read_error=None, type_key=None, project_radius_m=MOON_R, study_area=None):
    cs = []
    if r is None:
        cs.append(_chk("V01", "file_readable", FAIL, f"file could not be read as GeoTIFF: {read_error}"))
        return dict(status=FAIL, checks=cs, stats={}, usable_for_analysis=False)
    cs.append(_chk("V01", "file_readable", PASS, f"{r.shape[1]}x{r.shape[0]} px, {r.dtype}, {r.bands} band(s)"))
    cs.append(_chk("V02", "georeferenced", PASS if r.georef else FAIL, "georeferencing found" if r.georef else "no GeoTIFF georeferencing tags"))
    if r.georef:
        cs.append(_chk("V03", "rotation_free", FAIL if r.georef.rotated else PASS, "rotated/sheared transform is unsupported" if r.georef.rotated else "north-up grid"))
        ok = all(math.isfinite(v) and v > 0 for v in (r.georef.sx, r.georef.sy))
        cs.append(_chk("V04", "pixel_size_valid", PASS if ok else FAIL, f"pixel size {r.georef.sx:g} x {r.georef.sy:g} (native units)", sx=r.georef.sx, sy=r.georef.sy))
    c = r.crs
    cs.append(_chk("V05", "crs_defined", PASS if c.model != "unknown" else FAIL, f"CRS model: {c.model}"))
    body = {"moon": (PASS, "lunar reference body"), "earth": (FAIL, "TERRESTRIAL CRS (Earth ellipsoid): not valid for lunar data"),
            "other": (FAIL, "unrecognised body radius"), "unknown": (INDET, "body/radius not stated in the file; cannot confirm it is lunar")}[c.body]
    cs.append(_chk("V06", "crs_body", body[0], body[1], semi_major_m=c.semi_major_m, epsg=c.epsg))
    if c.body == "moon" and c.semi_major_m and abs(c.semi_major_m - project_radius_m) > 1.0:
        cs.append(_chk("V07", "reference_frame_consistent", WARN, f"radius {c.semi_major_m:.0f} m differs from project {project_radius_m:.0f} m"))
    else:
        cs.append(_chk("V07", "reference_frame_consistent", PASS if c.body == "moon" else NA, "matches project reference sphere" if c.body == "moon" else "not assessable"))
    proj_ok = c.model == "geographic" or c.projection == "polar_stereographic"
    cs.append(_chk("V08", "projection_supported", PASS if proj_ok else INDET,
                   f"{c.projection or c.model}: supported" if proj_ok else f"projection '{c.projection}' unsupported by the native engine; reproject first"))
    if c.model == "projected":
        cs.append(_chk("V09", "linear_unit_metric", PASS if c.linear_unit_m == 1.0 else (WARN if c.linear_unit_m == c.linear_unit_m else FAIL),
                       f"linear unit = {c.linear_unit_m} m (units are never assumed to be metres)"))
    stats = {}
    if r.data is not None:
        nd = r.nodata_mask(); n = nd.size; v = r.as_float()[~nd]
        stats = dict(pixels=int(n), nodata_pixels=int(nd.sum()), valid_fraction=float(1 - nd.mean()))
        if v.size:
            stats.update(min=float(v.min()), max=float(v.max()), mean=float(v.mean()), std=float(v.std()))
        cs.append(_chk("V10", "valid_data_present", FAIL if v.size == 0 else (WARN if stats["valid_fraction"] < 0.5 else PASS),
                       f"{stats['valid_fraction']:.1%} of pixels are valid", **stats))
        raw = r.data.astype(np.float64).ravel()
        fills = [f for f in FILL_CANDIDATES if r.nodata is None and (raw == f).mean() >= 0.0005]
        cs.append(_chk("V11", "nodata_declared", WARN if fills else (PASS if r.nodata is not None else NA),
                       f"NoData undeclared but sentinel value(s) {fills} are present: values were NOT masked" if fills else
                       ("NoData value declared" if r.nodata is not None else "no NoData declared; none suspected")))
        if v.size > 10:
            med = np.median(v); mad = np.median(np.abs(v - med)) * 1.4826
            frac = float((np.abs(v - med) > 10 * mad).mean()) if mad > 0 else 0.0
            cs.append(_chk("V12", "outliers_robust", WARN if frac > 0.02 else PASS, f"{frac:.2%} of values beyond 10 robust sigma (informational for heavy-tailed terrain)", fraction=frac))
            cs.append(_chk("V13", "not_constant", WARN if v.max() == v.min() else PASS, "constant raster" if v.max() == v.min() else "values vary"))
        if type_key in TYPES and v.size:
            lo, hi = TYPES[type_key][2]
            out = float(((v < lo) | (v > hi)).mean())
            cs.append(_chk("V14", "plausible_range", FAIL if out > 0.01 else (WARN if out > 0 else PASS),
                           f"{out:.2%} of values outside [{lo}, {hi}] for type '{type_key}'", fraction_outside=out))
    cs.append(_chk("V15", "single_band", WARN if r.bands > 1 else PASS, f"{r.bands} bands; only band 1 is read" if r.bands > 1 else "single band"))
    if study_area and r.georef and proj_ok:
        bb = lonlat_bbox(r)
        ov = not (bb["lon_max"] < study_area["lon_min"] or bb["lon_min"] > study_area["lon_max"] or bb["lat_max"] < study_area["lat_min"] or bb["lat_min"] > study_area["lat_max"])
        cs.append(_chk("V16", "study_area_overlap", PASS if ov else FAIL, "raster overlaps study area" if ov else "raster does not overlap study area", bbox=bb))
    else:
        cs.append(_chk("V16", "study_area_overlap", NA, "no study area defined, or CRS unsupported"))
    st = FAIL if any(x["status"] == FAIL for x in cs) else INDET if any(x["status"] == INDET for x in cs) else WARN if any(x["status"] == WARN for x in cs) else PASS
    return dict(status=st, checks=cs, stats=stats, usable_for_analysis=st != FAIL)


def compare_grids(a: Raster, b: Raster, max_ratio=2.0):
    """Compatibility of two rasters for joint analysis. Different grids are reported, never silently reconciled."""
    issues = []
    same = (a.crs.model == b.crs.model and a.crs.body == b.crs.body and a.crs.projection == b.crs.projection and a.crs.params == b.crs.params)
    if not same:
        issues.append("different CRS/projection: resampling onto a common grid is required (documented transformation)")
    try:
        ga, gb = ground_spacing(a), ground_spacing(b)
        sa, sb = float(np.nanmean(np.sqrt(ga[0] * ga[1]))), float(np.nanmean(np.sqrt(gb[0] * gb[1])))
    except UnsupportedError as e:
        return dict(compatible=False, issues=[str(e)], same_crs=same)
    ratio = max(sa, sb) / min(sa, sb)
    if ratio > max_ratio:
        issues.append(f"resolutions differ by {ratio:.1f}x ({sa:.2f} m vs {sb:.2f} m): coarse data cannot be treated as fine-scale observation")
    off = None
    if same:
        fx = ((b.georef.x0 - a.georef.x0) / a.georef.sx) % 1; fy = ((b.georef.y0 - a.georef.y0) / a.georef.sy) % 1
        off = (min(fx, 1 - fx), min(fy, 1 - fy))
        if ratio < 1.001 and max(off) > 0.01:
            issues.append(f"grids are offset by {off[0]:.2f} x {off[1]:.2f} pixel")
        l = max(a.bounds[0], b.bounds[0]); bt = max(a.bounds[1], b.bounds[1]); rr = min(a.bounds[2], b.bounds[2]); t = min(a.bounds[3], b.bounds[3])
        inter = max(0, rr - l) * max(0, t - bt); area = lambda x: (x.bounds[2] - x.bounds[0]) * (x.bounds[3] - x.bounds[1])
        overlap = inter / min(area(a), area(b))
        if overlap < 0.5:
            issues.append(f"overlap is only {overlap:.0%} of the smaller raster")
    else:
        overlap = None
    return dict(compatible=not issues, issues=issues, same_crs=same, spacing_m=[sa, sb], spacing_ratio=ratio, pixel_offset=off, overlap_fraction=overlap)
