"""End-to-end single-site pipeline: DEM -> terrain + environment products -> factor inputs -> gates/score."""
from __future__ import annotations
import datetime as dt, json
import numpy as np
from . import __version__, geo, terrain, environment as env, quicklook, scoring as S
from .workspace import utc

# EXAMPLE_ONLY configuration for the SYNTHETIC demo. Thresholds are NOT mission requirements.
DEMO_CFG = dict(
    analysis=dict(roughness_window_m=250.0, relief_window_m=500.0, crater=dict(scales_m=[150, 200, 260, 340, 450, 600], morphology="bowl"),
                  environment=dict(start_utc="2026-11-10T00:00:00Z", days=29.53, step_h=12.0, max_shadow_dist_m=2500.0)),
    gates=[dict(id="G1", factor="slope", op="<=", limit=25.0, unit="deg", min_coverage=0.9, requirement_ref="EXAMPLE_ONLY (synthetic demo)")],
    preferences=[dict(factor="slope", weight=3, best=0, worst=25), dict(factor="roughness", weight=2, best=0, worst=5),
                 dict(factor="illumination_duration", weight=2, best=1, worst=0), dict(factor="earth_visibility", weight=2, best=1, worst=0),
                 dict(factor="crater_density", weight=1, best=0, worst=20)],
    min_score_coverage=0.5)


def build_gates_prefs(cfg):
    return [S.Gate(**g) for g in cfg.get("gates", [])], [S.Pref(**p) for p in cfg.get("preferences", [])]


def _times(e):
    t0 = dt.datetime.fromisoformat(e["start_utc"].replace("Z", "+00:00")).timestamp()
    return t0 + np.arange(int(round(e["days"] * 24 / e["step_h"]))) * e["step_h"] * 3600.0


def run_site(ws, dem_id, cfg, progress=lambda msg, f: None):
    rec = ws.get(dem_id); r = ws.raster(dem_id)
    if ws.effective_type(dem_id) != "dem":
        raise ValueError("dataset is not confirmed/identified as a DEM")
    if rec["quality"]["status"] == "FAIL" or r.crs.body == "earth":
        raise ValueError("DEM failed validation (terrestrial CRS or other FAIL): analysis refused")
    if r.crs.body == "unknown" and not cfg.get("acknowledge_unknown_crs"):
        raise ValueError("CRS body unknown: set acknowledge_unknown_crs=true to proceed (recorded in manifest)")
    a = cfg["analysis"]; z = r.as_float(); g = env.pixel_geometry(r); dx, dy = g["dxg"], g["dyg"]
    sp = float(np.nanmean(np.sqrt(dx * dy))); ins = [dem_id]; out = {}
    progress("slope/aspect", 0.05)
    gx, gy = terrain.horn_gradient(z, dx, dy, 1)
    slope = terrain.slope_deg(gx, gy)
    asp = terrain.aspect_deg(gx * g["ex"] + gy * g["ey"], gx * g["nx"] + gy * g["ny"])
    wr = max(3, int(round(a["roughness_window_m"] / sp))) | 1; wl = max(3, int(round(a["relief_window_m"] / sp))) | 1
    curv, relief, rough = terrain.curvature(z, dx, dy), terrain.local_relief(z, wl), terrain.roughness_rms(z, wr)
    ex = ws.root / "exports"; ex.mkdir(exist_ok=True)
    products = [("slope", slope, "deg", "Horn slope", "horn_slope", dict(baseline_px=2, ground_spacing_m=sp, scale_correction=True)),
                ("aspect", asp, "deg", "downslope azimuth from north", "aspect", {}),
                ("curvature", curv, "1/m", "Laplacian curvature (+ concave)", "laplacian_curvature", {}),
                ("local_relief", relief, "m", f"max-min, window {wl} px", "local_relief", dict(window_px=wl, window_m=wl * sp)),
                ("roughness", rough, "m", f"RMS plane-residual height, window {wr} px", "roughness_rms", dict(window_px=wr, window_m=wr * sp))]
    progress("craters", 0.2)
    cands, cinfo = terrain.detect_craters(z, sp, a["crater"]["scales_m"], a["crater"]["morphology"])
    (ws.root / "derived" / "crater_candidates.json").write_text(json.dumps(dict(
        note="CANDIDATES requiring human review; edit review_status to accepted/rejected", info=cinfo, candidates=cands), indent=1))
    env_cfg = a["environment"]; times = _times(env_cfg); md = env_cfg["max_shadow_dist_m"]
    progress("illumination", 0.35)
    il = env.illumination_series(r, z, times, md)
    progress("earth visibility", 0.65)
    ev = env.earth_visibility_series(r, z, times, md)
    products += [("illumination_fraction", il["fraction"], "fraction", "sunlit fraction over window", "terrain_horizon_illumination", dict(env_cfg, **il_meta(il))),
                 ("illumination_longest_dark_h", il["longest_outage_h"], "h", "longest continuous dark period", "terrain_horizon_illumination", dict(env_cfg)),
                 ("earth_visibility_fraction", ev["fraction"], "fraction", "Earth-visible fraction", "terrain_horizon_earth_visibility", dict(env_cfg, **il_meta(ev))),
                 ("earth_longest_outage_h", ev["longest_outage_h"], "h", "longest Earth outage", "terrain_horizon_earth_visibility", dict(env_cfg)),
                 ("illumination_incomplete_fraction", il["incomplete_fraction"], "fraction", "horizon unknown (ray left DEM)", "terrain_horizon_illumination", {})]
    for name, arr, u, d, algo, params in products:
        out[name] = ws.save_derived(name, arr, r, u, d, algo, params, ins)["id"]
    progress("rendering", 0.9)
    hs = terrain.hillshade(gx, gy)
    quicklook.render(ex / "hillshade.png", hs, "hillshade"); quicklook.render(ex / "dem.png", z, "dem"); quicklook.render(ex / "slope.png", slope, "slope")
    quicklook.render(ex / "illumination_fraction.png", il["fraction"], "slope", 0, 1); quicklook.render(ex / "earth_visibility_fraction.png", ev["fraction"], "slope", 0, 1)
    # ---- factor inputs (site level = whole DEM footprint; zone-level analysis is future work)
    valid = np.isfinite(z); tot = z.size; vf = float(valid.mean());   # coverage denominators = whole raster extent, never only the valid pixels
    area_km2 = float(valid.sum() * np.nanmean(dx * dy) / 1e6)
    p95 = lambda a: float(np.nanpercentile(a[np.isfinite(a)], 95)) if np.isfinite(a).any() else None
    rel = lambda arr, inc: float(np.isfinite(arr[inc < 0.05]).mean() * np.isfinite(arr).mean()) if np.isfinite(arr).any() else 0.0
    reliable = np.nan_to_num(il["incomplete_fraction"], nan=1.0) < 0.05
    cov_env = float((reliable & valid).sum() / tot)
    n_c = sum(1 for c in cands if c["confidence"] != "very_low")
    FI = S.FactorInput
    inputs = {"slope": FI(p95(slope), "deg", float(np.isfinite(slope).sum() / tot), None, "horn_stride1", sp, ins, "p95"),
              "roughness": FI(p95(rough), "m", float(np.isfinite(rough).sum() / tot), None, f"rms_plane_w{wr}", sp, ins, "p95"),
              "local_relief": FI(float(np.nanmedian(relief)), "m", float(np.isfinite(relief).sum() / tot), None, f"relief_w{wl}", sp, ins, "median"),
              "crater_density": FI(n_c / area_km2, "candidates/km2", vf, None, f"log_{a['crater']['morphology']}_unreviewed", sp, ins, "count/area (UNREVIEWED candidates)"),
              "illumination_duration": FI(float(np.nanmean(il["fraction"][reliable])) if reliable.any() else None, "fraction", cov_env, None, "horizon_ray_march", sp, ins, "mean over reliable pixels"),
              "earth_visibility": FI(float(np.nanmean(ev["fraction"][reliable])) if reliable.any() else None, "fraction", cov_env, None, "horizon_ray_march", sp, ins, "mean over reliable pixels")}
    gates, prefs = build_gates_prefs(cfg)
    ev_site = S.evaluate_site(ws.project()["site_id"], inputs, gates, prefs, cfg.get("min_score_coverage", 0.8))
    res = dict(software_version=__version__, generated_utc=utc(), dem=dem_id, synthetic=rec.get("synthetic", False), config=cfg, ground_spacing_m=sp,
               area_km2=area_km2, valid_fraction=vf, crater_candidates=len(cands), crater_info=cinfo, derived=out,
               factor_inputs={k: v.__dict__ for k, v in inputs.items()}, evaluation=ev_site,
               limitations=["site-level statistics over the whole DEM, not landing-footprint zones",
                            "terrain beyond the DEM edge is unknown: edge pixels flagged incomplete and excluded from environment statistics",
                            "thermal, radiation, micrometeoroid, resource and relay factors are NOT assessed",
                            "scores are relative preference indicators, not probabilities of landing success or safety certification"])
    (ws.root / "reports" / "site_result.json").write_text(json.dumps(res, indent=1, default=str)); ws.log("pipeline_run", dem=dem_id, status=ev_site["status"])
    progress("done", 1.0)
    return res


def il_meta(d):
    return dict(n_steps=d["n_steps"], step_h=d["step_h"])
