"""Report generation: JSON summary, CSV factor table, PDF. Reads only recorded results/manifests (no recomputation)."""
from __future__ import annotations
import csv, hashlib, json, platform, sys
from pathlib import Path
import numpy as np
from . import __version__, factors as F


def build_json(ws):
    res = json.loads((ws.root / "reports" / "site_result.json").read_text())
    inputs = [{k: d.get(k) for k in ("id", "kind", "original_filename", "name", "sha256", "data_class", "synthetic", "units", "crs", "native_pixel_size", "site", "provenance", "instrument_source", "dataset_type", "quality", "status")}
              | {"processing_history": d.get("processing_history")} for d in ws.datasets()]
    fi = res["factor_inputs"]
    cov = [dict(id=f.id, key=f.key, name=f.name, implementation=f.status, assessed=f.key in fi and fi[f.key]["stat"] is not None,
                status=("ASSESSED" if f.key in fi and fi[f.key]["stat"] is not None else "NOT_ASSESSED")) for f in F.FACTORS]
    out = dict(report_type="LunaSelect site engineering report", software_version=__version__, project=ws.project(), synthetic_demo=res["synthetic"],
               disclaimer="Independent research software; not NASA/JPL developed or certified. Scores are relative preference indicators, not probabilities of landing success.",
               input_manifest=inputs, factor_coverage=cov, results=res["evaluation"], factor_inputs=fi, crater_candidates=res["crater_candidates"],
               algorithms=sorted({h["step"] for d in ws.datasets() for h in d.get("processing_history", [])}), assumptions=res["config"],
               limitations=res["limitations"], failed_gates=[g for g in res["evaluation"]["gates"] if g["status"] == "FAIL"],
               reproducibility=dict(config_sha256=hashlib.sha256(json.dumps(res["config"], sort_keys=True, default=str).encode()).hexdigest(),
                                    python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(), integrity_mismatches=ws.verify_integrity(),
                                    note="all algorithms are deterministic; Monte Carlo (multi-site) uses a fixed seed"))
    (ws.root / "reports" / "site_report.json").write_text(json.dumps(out, indent=1, default=str)); return out


def write_csv(ws, rep):
    p = ws.root / "reports" / "factor_table.csv"
    rows = {r["factor"]: r for r in rep["results"]["factors"]}
    with open(p, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["id", "factor", "implementation_status", "assessment_status", "stat", "stat_name", "unit", "coverage", "weight", "rating", "contribution"])
        for c in rep["factor_coverage"]:
            fi = rep["factor_inputs"].get(c["key"], {}); r = rows.get(c["key"], {})
            w.writerow([c["id"], c["name"], c["implementation"], r.get("status", "NOT_ASSESSED"), fi.get("stat"), fi.get("stat_name"), fi.get("unit"), fi.get("coverage"), r.get("weight"), r.get("rating"), r.get("contribution")])
    return p


def write_pdf(ws, rep):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    st = getSampleStyleSheet(); p = ws.root / "reports" / "site_report.pdf"; doc = SimpleDocTemplate(str(p), pagesize=A4, leftMargin=1.5 * cm, rightMargin=1.5 * cm)
    P = lambda t, s="BodyText": Paragraph(t, st[s]); S = []
    tb = lambda rows, w=None: (lambda t: (t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .3, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 7), ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)])), t)[1])(Table(rows, colWidths=w, repeatRows=1))
    proj, ev = rep["project"], rep["results"]
    S += [P(f"LunaSelect site engineering report: {proj['site_id']}", "Title")]
    if rep["synthetic_demo"]: S += [P("<b>SYNTHETIC DEMONSTRATION DATA. Not lunar measurements. Do not use for mission decisions.</b>")]
    S += [P(rep["disclaimer"]), P(f"Software {rep['software_version']} | project {proj['project_id']} | created {proj['created_utc']}"), Spacer(1, 6)]
    S += [P("1. Mission profile and site identity", "Heading2"), P(f"Mission configuration: {proj.get('mission') or 'not specified'}. Site identity is assigned by the project ({proj['site_id']}), never from filenames.")]
    S += [P("2. Input manifest and provenance", "Heading2"), tb([["id", "file", "sha256[:12]", "type", "class", "quality"]] + [[d["id"], d.get("original_filename") or d.get("name"), (d["sha256"] or "")[:12], (d["dataset_type"] or {}).get("confirmed") or (d["dataset_type"] or {}).get("suggested"), d["data_class"], (d.get("quality") or {}).get("status", "-")] for d in rep["input_manifest"]])]
    S += [P("3. Algorithms and processing history", "Heading2"), P(", ".join(rep["algorithms"]))]
    S += [P("4. Factor coverage (catalogue is a proposal requiring engineering approval)", "Heading2"),
          tb([["#", "factor", "implementation", "assessment"]] + [[c["id"], c["name"], c["implementation"], c["status"]] for c in rep["factor_coverage"]])]
    S += [P("5. Safety gates", "Heading2"), tb([["gate", "factor", "limit", "observed", "status", "detail"]] + [[g["id"], g["factor"], f"{g['op']} {g['limit']} {g['unit']}", g.get("observed"), g["status"], g["detail"]] for g in ev["gates"]])]
    S += [P(f"6. Result: overall status <b>{ev['status']}</b>; relative preference score {ev['score']} over {ev['score_coverage']:.0%} of the weight (not a probability of landing success).", "Heading2"),
          tb([["factor", "status", "value", "rating", "weight", "contribution"]] + [[r["factor"], r["status"], r.get("value"), r.get("rating"), round(r["weight"], 3), r.get("contribution")] for r in ev["factors"]])]
    S += [PageBreak(), P("7. Maps (derived from the DEM; see GeoTIFF products in derived/)", "Heading2")]
    for n in ("dem", "hillshade", "slope", "illumination_fraction", "earth_visibility_fraction"):
        q = ws.root / "exports" / f"{n}.png"
        if q.exists(): S += [P(n.replace("_", " ")), Image(str(q), width=8 * cm, height=8 * cm, kind="proportional")]
    S += [P("8. Uncertainty", "Heading2"), P("Single-site run: rank stability and Monte Carlo analysis require two or more comparable sites and are NOT ASSESSED here. Ephemeris accuracy ~0.1 deg; crater diameters +/-35%.")]
    S += [P("9. Limitations", "Heading2")] + [P("- " + l) for l in rep["limitations"]]
    S += [P("10. Reproducibility", "Heading2"), P(json.dumps(rep["reproducibility"]))]
    doc.build(S); return p


def build_all(ws):
    rep = build_json(ws); return dict(json=str(ws.root / "reports" / "site_report.json"), csv=str(write_csv(ws, rep)), pdf=str(write_pdf(ws, rep)))
