"""Stage A mandatory constraints (framework + slope evaluator). A FAIL is never offset by other scores.
Thresholds are supplied by the mission engineer; this module ships NO default threshold values."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import numpy as np


class Status(str, Enum):
    PASS = "PASS"; FAIL = "FAIL"; INDETERMINATE = "INDETERMINATE"; NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass(frozen=True)
class Constraint:
    id: str; factor: int; metric: str; max_value: float; unit: str; requirement_ref: str; min_valid_fraction: float = 0.95


def evaluate_max(c: Constraint, values: np.ndarray | None, applicable: bool = True) -> dict:
    """Zone-level maximum-value constraint (e.g. slope). INDETERMINATE when evidence coverage is too low."""
    if not applicable:
        return dict(id=c.id, status=Status.NOT_APPLICABLE, detail="not applicable to this mission configuration")
    if values is None or values.size == 0:
        return dict(id=c.id, status=Status.INDETERMINATE, detail="no data supplied")
    v = values[np.isfinite(values)]; cov = v.size / values.size
    mx = float(v.max()) if v.size else None
    if mx is not None and mx > c.max_value:
        return dict(id=c.id, status=Status.FAIL, observed_max=mx, limit=c.max_value, unit=c.unit, coverage=cov,
                    detail="limit exceeded within valid pixels (fails regardless of coverage)")
    if cov < c.min_valid_fraction:
        return dict(id=c.id, status=Status.INDETERMINATE, observed_max=mx, limit=c.max_value, unit=c.unit, coverage=cov,
                    detail=f"valid coverage {cov:.1%} below required {c.min_valid_fraction:.0%}; unobserved pixels may exceed the limit")
    return dict(id=c.id, status=Status.PASS, observed_max=mx, limit=c.max_value, unit=c.unit, coverage=cov, detail="within limit")
