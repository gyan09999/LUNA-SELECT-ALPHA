"""Safety gates (hard constraints) separated from weighted preferences. No default favourable score for missing data.
Statuses: PASS, FAIL, CONDITIONAL, INSUFFICIENT_DATA, NOT_ASSESSED. A score is a relative ranking aid only; it is
NOT a probability of landing success and NOT a safety certification."""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

PASS, FAIL, COND, INSUF, NOTA = "PASS", "FAIL", "CONDITIONAL", "INSUFFICIENT_DATA", "NOT_ASSESSED"


@dataclass
class FactorInput:
    stat: float | None; unit: str; coverage: float; sigma: float | None = None
    method: str = ""; spacing_m: float | None = None; sources: list = field(default_factory=list); stat_name: str = ""


@dataclass
class Gate:
    id: str; factor: str; op: str; limit: float; unit: str; min_coverage: float = 0.9; requirement_ref: str = "UNSPECIFIED"


@dataclass
class Pref:
    factor: str; weight: float; best: float; worst: float; method: str = "linear"; min_coverage: float = 0.9


def eval_gate(g: Gate, fi: FactorInput | None) -> dict:
    base = dict(id=g.id, factor=g.factor, op=g.op, limit=g.limit, unit=g.unit, requirement_ref=g.requirement_ref)
    if fi is None or fi.stat is None:
        return base | dict(status=NOTA, detail="no input data for this factor")
    if fi.unit != g.unit:
        return base | dict(status=INSUF, detail=f"unit mismatch: data in '{fi.unit}', gate in '{g.unit}'")
    margin = (g.limit - fi.stat) if g.op == "<=" else (fi.stat - g.limit)
    base |= dict(observed=fi.stat, stat_name=fi.stat_name, margin=margin, coverage=fi.coverage)
    if margin < 0:
        return base | dict(status=FAIL, detail="limit violated (a FAIL is not offset by any other score)")
    if fi.coverage < g.min_coverage:
        return base | dict(status=INSUF, detail=f"coverage {fi.coverage:.0%} < required {g.min_coverage:.0%}; unobserved area may violate the limit")
    if fi.sigma and margin < 2 * fi.sigma:
        return base | dict(status=COND, detail=f"within 2 sigma ({2 * fi.sigma:.3g} {g.unit}) of the limit")
    return base | dict(status=PASS, detail="within limit")


def normalise(x, best, worst, method="linear"):
    t = float(np.clip((x - worst) / (best - worst), 0, 1))
    return t * t * (3 - 2 * t) if method == "smoothstep" else t


def evaluate_site(site, inputs: dict, gates: list, prefs: list, min_score_coverage=0.8, factors=None, method=None):
    gr = [eval_gate(g, inputs.get(g.factor)) for g in gates]
    wtot = sum(p.weight for p in prefs) or 1.0
    rows, num, den = [], 0.0, 0.0
    for p in prefs:
        fi = inputs.get(p.factor)
        if factors is not None and p.factor not in factors:
            continue
        row = dict(factor=p.factor, weight=p.weight / wtot)
        if fi is None or fi.stat is None:
            rows.append(row | dict(status=NOTA)); continue
        if fi.coverage < p.min_coverage:
            rows.append(row | dict(status=INSUF, coverage=fi.coverage)); continue
        r = normalise(fi.stat, p.best, p.worst, method or p.method)
        rows.append(row | dict(status="ASSESSED", value=fi.stat, unit=fi.unit, rating=r, contribution=row["weight"] * r, coverage=fi.coverage))
        num += p.weight * r; den += p.weight
    cov = den / wtot if wtot else 0.0
    st = [g["status"] for g in gr]
    overall = (FAIL if FAIL in st else NOTA if not gr else INSUF if (INSUF in st or NOTA in st) else
               COND if (COND in st or cov < min_score_coverage) else PASS)
    return dict(site=site, gates=gr, factors=rows, score=(num / den if den else None), score_coverage=cov, status=overall)


def comparability(inputs_by_site: dict, prefs: list, max_spacing_ratio=2.0):
    """Factors usable for ranking: assessed at every site with equal unit, same method and compatible resolution."""
    ok, flags = [], []
    for p in prefs:
        fis = [d.get(p.factor) for d in inputs_by_site.values()]
        if any(f is None or f.stat is None or f.coverage < p.min_coverage for f in fis):
            flags.append((p.factor, "not assessed with sufficient coverage at every site")); continue
        if len({f.unit for f in fis}) > 1 or len({f.method for f in fis}) > 1:
            flags.append((p.factor, "units or processing methods differ between sites")); continue
        sp = [f.spacing_m for f in fis if f.spacing_m]
        if sp and max(sp) / min(sp) > max_spacing_ratio:
            flags.append((p.factor, f"resolutions differ by {max(sp) / min(sp):.1f}x")); continue
        ok.append(p.factor)
    return ok, flags


def compare_sites(inputs_by_site, gates, prefs, min_common_weight=0.5, min_score_coverage=0.8, mc=1000, sigma_w=0.25, seed=42):
    common, flags = comparability(inputs_by_site, prefs)
    wsum = sum(p.weight for p in prefs) or 1.0
    cw = sum(p.weight for p in prefs if p.factor in common) / wsum
    ev = {s: evaluate_site(s, i, gates, prefs, min_score_coverage, factors=common) for s, i in inputs_by_site.items()}
    res = dict(sites=ev, common_factors=common, incomparable=flags, common_weight_fraction=cw, ranking=[], stability=None)
    if cw < min_common_weight or not common:
        res["note"] = f"NOT COMPARABLE: common assessed factors carry {cw:.0%} of the weight (< {min_common_weight:.0%}); no ranking produced"
        return res
    elig = [s for s, e in ev.items() if e["status"] in (PASS, COND) and e["score"] is not None]
    order = sorted(elig, key=lambda s: -ev[s]["score"])
    res["ranking"] = [dict(rank=i + 1, site=s, score=ev[s]["score"], status=ev[s]["status"],
                           top_contributors=sorted([(r["factor"], r["contribution"]) for r in ev[s]["factors"] if r["status"] == "ASSESSED"], key=lambda t: -t[1])[:3])
                      for i, s in enumerate(order)]
    res["excluded"] = {s: e["status"] for s, e in ev.items() if s not in elig}
    if len(elig) > 1:
        res["stability"] = _stability(elig, inputs_by_site, prefs, common, mc, sigma_w, seed, order)
    return res


def _stability(sites, inputs, prefs, common, n, sigma_w, seed, nominal):
    rng = np.random.default_rng(seed); ps = [p for p in prefs if p.factor in common]
    ranks = {s: [] for s in sites}
    for _ in range(n):
        w = np.array([p.weight for p in ps]) * np.exp(rng.normal(0, sigma_w, len(ps)))
        sc = {}
        for s in sites:
            tot = 0.0
            for wi, p in zip(w, ps):
                fi = inputs[s][p.factor]; x = fi.stat + (rng.normal(0, fi.sigma) if fi.sigma else 0.0)
                tot += wi * normalise(x, p.best, p.worst, p.method)
            sc[s] = tot / w.sum()
        for i, s in enumerate(sorted(sites, key=lambda k: -sc[k])):
            ranks[s].append(i + 1)
    alt = {}
    for m in ("linear", "smoothstep"):
        e = {s: evaluate_site(s, inputs[s], [], ps, 0, factors=common, method=m)["score"] for s in sites}
        alt[m] = sorted(sites, key=lambda k: -e[k])
    oat = {}
    for p in ps:
        for f in (0.5, 1.5):
            e = {s: sum((q.weight * (f if q.factor == p.factor else 1)) * normalise(inputs[s][q.factor].stat, q.best, q.worst, q.method) for q in ps) for s in sites}
            oat[f"{p.factor} x{f}"] = sorted(sites, key=lambda k: -e[k])[0]
    return dict(n=n, seed=seed, sigma_weight_lognormal=sigma_w, value_perturbation="only where factor sigma is provided",
                per_site={s: dict(mean_rank=float(np.mean(r)), rank_p05=int(np.percentile(r, 5)), rank_p95=int(np.percentile(r, 95)),
                                  fraction_rank1=float(np.mean(np.array(r) == 1))) for s, r in ranks.items()},
                normalisation_orderings=alt, normalisation_stable=alt["linear"] == alt["smoothstep"],
                one_at_a_time_top_site=oat, nominal_order=nominal,
                note="fractions are over simulated perturbations, not probabilities of landing success")
