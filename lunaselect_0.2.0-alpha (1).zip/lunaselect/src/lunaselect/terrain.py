"""Terrain analysis: Horn gradient, slope, hillshade, DEM summary. No NoData is ever filled or interpolated."""
from __future__ import annotations
import numpy as np


def stride_for_baseline(baseline_m, spacing_m):
    return max(1, int(round(baseline_m / (2 * spacing_m)))) if baseline_m else 1


def horn_gradient(z, dx, dy, stride=1):
    """Eastward and northward elevation gradients (m/m) using Horn's 3x3 kernel with neighbour offset `stride`.
    Effective baseline = 2*stride*pixel spacing. Pixels with any NoData neighbour (or on the edge) are NaN."""
    s, (h, w) = stride, z.shape
    p = np.pad(z, s, constant_values=np.nan)
    n = lambda dr, dc: p[s + dr * s: s + dr * s + h, s + dc * s: s + dc * s + w]
    a, b, c, d, f, g, hh, i = n(-1, -1), n(-1, 0), n(-1, 1), n(0, -1), n(0, 1), n(1, -1), n(1, 0), n(1, 1)
    dzdx = ((c + 2 * f + i) - (a + 2 * d + g)) / (8 * s * dx)
    dzdy = ((a + 2 * b + c) - (g + 2 * hh + i)) / (8 * s * dy)
    bad = ~np.isfinite(z)                       # Horn ignores the centre pixel: invalid pixels must not receive a value
    return np.where(bad, np.nan, dzdx), np.where(bad, np.nan, dzdy)


def slope_deg(dzdx, dzdy):
    return np.degrees(np.arctan(np.hypot(dzdx, dzdy))).astype(np.float32)


def hillshade(dzdx, dzdy, azimuth=315.0, altitude=45.0):
    az, el = np.radians(azimuth), np.radians(altitude)
    shade = (-dzdx * np.sin(az) * np.cos(el) - dzdy * np.cos(az) * np.cos(el) + np.sin(el)) / np.sqrt(1 + dzdx ** 2 + dzdy ** 2)
    return np.clip(shade, 0, 1).astype(np.float32)


def summarise(z, slope=None):
    v = z[np.isfinite(z)]
    out = dict(pixels_total=int(z.size), pixels_valid=int(v.size), valid_fraction=float(v.size / z.size))
    if v.size:
        q = np.percentile(v, [1, 5, 25, 50, 75, 95, 99])
        out["elevation_m"] = dict(min=float(v.min()), max=float(v.max()), mean=float(v.mean()), std=float(v.std()),
                                  relief=float(v.max() - v.min()), percentiles=dict(zip(("p1", "p5", "p25", "p50", "p75", "p95", "p99"), map(float, q))))
    if slope is not None:
        s = slope[np.isfinite(slope)]
        if s.size:
            out["slope_deg"] = dict(valid_pixels=int(s.size), mean=float(s.mean()), median=float(np.median(s)), p95=float(np.percentile(s, 95)),
                                    p99=float(np.percentile(s, 99)), max=float(s.max()),
                                    fraction_above={str(t): float((s > t).mean()) for t in (5, 10, 15, 20)},
                                    note="reference fractions only; they are NOT mission constraints")
    return out


# ---------------------------------------------------------------- aspect, curvature, relief, roughness
def aspect_deg(dzdx_e, dzdy_n):
    """Downslope direction, degrees clockwise from north (NaN where slope is exactly zero)."""
    a = (np.degrees(np.arctan2(-dzdx_e, -dzdy_n)) + 360) % 360
    return np.where((dzdx_e == 0) & (dzdy_n == 0), np.nan, a).astype(np.float32)


def curvature(z, dx, dy):
    """Laplacian curvature (1/m) = d2z/dx2 + d2z/dy2 from a 3x3 stencil; positive = concave (bowl/pit)."""
    p = np.pad(z, 1, constant_values=np.nan)
    zc, zw, ze, zn, zs = p[1:-1, 1:-1], p[1:-1, :-2], p[1:-1, 2:], p[:-2, 1:-1], p[2:, 1:-1]
    return ((ze - 2 * zc + zw) / dx ** 2 + (zn - 2 * zc + zs) / dy ** 2).astype(np.float32)


def _window_fn(z, win, fn):
    """NaN-propagating moving-window max/min: any window containing NoData -> NaN (no silent filling)."""
    from scipy import ndimage as ndi
    bad = ndi.maximum_filter((~np.isfinite(z)).astype(np.uint8), size=win, mode="constant", cval=1)
    f = fn(np.nan_to_num(z, nan=0.0), size=win, mode="nearest")
    return np.where(bad > 0, np.nan, f).astype(np.float32)


def local_relief(z, win):
    from scipy import ndimage as ndi
    return _window_fn(z, win, ndi.maximum_filter) - _window_fn(z, win, ndi.minimum_filter)


def roughness_rms(z, win):
    """RMS height (m) of residuals about the least-squares plane in each win x win window.
    Windows touching NoData or the raster edge are NaN. Value depends on window size in metres
    (win * pixel spacing): always report both."""
    from scipy import ndimage as ndi
    win = win | 1
    bad = ndi.maximum_filter((~np.isfinite(z)).astype(np.uint8), size=win, mode="constant", cval=1) > 0
    zz = np.where(np.isfinite(z), z, 0.0).astype(np.float64)
    k = np.arange(win) - win // 2
    kx, ky = np.tile(k, (win, 1)).astype(float), np.tile(k[:, None], (1, win)).astype(float)
    n = win * win; vx = (kx ** 2).sum() / n
    mean = ndi.uniform_filter(zz, win, mode="reflect"); m2 = ndi.uniform_filter(zz ** 2, win, mode="reflect")
    cx = ndi.correlate(zz, kx / n, mode="reflect"); cy = ndi.correlate(zz, ky / n, mode="reflect")
    var = m2 - mean ** 2 - cx ** 2 / vx - cy ** 2 / vx
    return np.where(bad, np.nan, np.sqrt(np.maximum(var, 0))).astype(np.float32)


# ---------------------------------------------------------------- crater candidate detection
DIAM_FACTOR = {"bowl": 1.347, "flat_floor": 1.01}   # D_true / D_LoG, calibrated numerically on ideal synthetic craters


def geometric_scales(dmin, dmax, ratio=1.15):
    out, d = [], float(dmin)
    while d <= dmax * 1.0001:
        out.append(d); d *= ratio
    return out


def detect_craters(z, spacing_m, scales_m, morphology="bowl", response_min=0.02, nms_overlap=0.6):
    """Crater CANDIDATE detection by scale-normalised Laplacian-of-Gaussian (LoG) blob search.
    Candidates are local maxima in (row, col, scale). Trial 'scale diameter' D_s = 2*sqrt2*sigma. The LoG peak scale
    relates to true radius R by sigma*/R = 0.525 for an ideal parabolic bowl and 0.70 for a flat-floored cylinder
    (numerical calibration, tests), so diameter_m = DIAM_FACTOR[morphology] * D_s (REAL craters lie in between:
    treat diameter as +/-35%; `scale_diameter_m` is the uncorrected value). depth = regional plane (fit to annulus
    1.15-1.5 R) minus floor minimum inside 0.5 R. Candidates whose 1.5 R window is truncated by the DEM edge or contains
    NoData are dropped (reported count). Every candidate has review_status='needs_review'. Not validated on real data."""
    from scipy import ndimage as ndi
    H, W = z.shape; f = DIAM_FACTOR[morphology]
    zf = np.where(np.isfinite(z), z, np.nanmedian(z))
    bad = ndi.maximum_filter((~np.isfinite(z)).astype(np.uint8), size=int(max(scales_m) * f / spacing_m) | 1) > 0
    sig = [(D / (2 * np.sqrt(2))) / spacing_m for D in scales_m]
    stack = np.stack([ndi.gaussian_laplace(zf, s, mode="nearest") * s ** 2 for s in sig]); stack = np.where(bad[None], 0, stack)
    pk = (stack == ndi.maximum_filter(stack, size=(3, 5, 5))) & (stack > np.array(scales_m)[:, None, None] * response_min / 8)
    yy, xx = np.ogrid[:H, :W]; cand, dropped = [], 0
    for s, r, c in zip(*np.nonzero(pk)):
        Rpx = 0.5 * scales_m[s] * f / spacing_m; w = int(np.ceil(1.5 * Rpx))
        if min(r, c, H - 1 - r, W - 1 - c) < w or not np.isfinite(z[r - w:r + w + 1, c - w:c + w + 1]).all():
            dropped += 1; continue
        rr = np.hypot(yy - r, xx - c); ring = (rr >= 1.15 * Rpx) & (rr <= 1.5 * Rpx)
        A = np.c_[np.ones(ring.sum()), (xx + 0 * yy)[ring], (yy + 0 * xx)[ring]]
        coef = np.linalg.lstsq(A, z[ring], rcond=None)[0]
        res = z - (coef[0] + coef[1] * xx + coef[2] * yy)
        inn = res[rr <= .5 * Rpx]; D = 2 * Rpx * spacing_m; depth = float(-inn.min())
        rim = res[(rr >= .9 * Rpx) & (rr <= 1.1 * Rpx)]
        cand.append(dict(row=int(r), col=int(c), diameter_m=float(D), scale_diameter_m=float(scales_m[s]), depth_m=depth,
                         depth_over_diameter=depth / D, response=float(stack[s, r, c]),
                         rim_scatter_over_depth=float(rim.std() / depth) if depth > 0 else float("inf")))
    cand.sort(key=lambda k: -k["response"]); keep = []
    for k in cand:
        if all(np.hypot(k["row"] - q["row"], k["col"] - q["col"]) * spacing_m > nms_overlap * 0.5 * (k["diameter_m"] + q["diameter_m"]) for q in keep):
            keep.append(k)
    for k in keep:
        ok = 0.04 <= k["depth_over_diameter"] <= 0.25; sc = k["rim_scatter_over_depth"]
        k["confidence"] = ("very_low" if not ok or sc > 0.4 else "medium" if sc <= 0.2 and k["response"] > 0.05 * k["scale_diameter_m"] else "low")
        k["review_status"] = "needs_review"
    return keep, dict(dropped_edge_or_nodata=dropped, morphology=morphology, diameter_factor=f, scales_m=list(map(float, scales_m)))
