"""Local persistent project workspace: immutable originals, versioned manifests, derived products, event log.
Layout: project.yaml, originals/ (read-only), derived/, manifests/, reports/, exports/, logs/events.jsonl"""
from __future__ import annotations
import datetime as dt, hashlib, json, os, re, shutil
from pathlib import Path
import numpy as np, yaml
from . import __version__, geo, identify, validate

DATA_CLASSES = ("raw", "calibrated", "derived", "simulated", "unspecified")
SITE_RE = re.compile(r"site[\s_\-]*0*(\d+)", re.I)
ADAPTERS = {   # honest reader-adapter status table
    ".tif": ("native GeoTIFF reader", "implemented_tested"), ".tiff": ("native GeoTIFF reader", "implemented_tested"),
    ".img": ("PDS3/PDS4 binary raster adapter", "not_implemented: needs product label + schema; convert to GeoTIFF externally (e.g. GDAL)"),
    ".lbl": ("PDS3 label adapter", "not_implemented"), ".xml": ("PDS4 label adapter", "not_implemented"), ".cub": ("ISIS cube adapter", "not_implemented"),
    ".csv": ("CSV adapter", "not_implemented"), ".geojson": ("vector adapter", "blocked: geopandas/shapely not available offline"),
    ".gpkg": ("vector adapter", "blocked: geopandas/shapely not available offline"), ".shp": ("vector adapter", "blocked: geopandas/shapely not available offline"),
    ".nc": ("NetCDF adapter", "not_implemented"), ".h5": ("HDF5 adapter", "not_implemented"), ".hdf5": ("HDF5 adapter", "not_implemented")}


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def sha256_file(p, chunk=1 << 20):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def site_hint(name):
    m = SITE_RE.search(name); return int(m.group(1)) if m else None


class Workspace:
    SUB = ("originals", "derived", "manifests", "reports", "exports", "logs")

    def __init__(self, root):
        self.root = Path(root)

    @classmethod
    def create(cls, root, project_id, site_id, mission=None, study_area=None, radius_m=geo.MOON_R):
        ws = cls(root)
        for s in cls.SUB:
            (ws.root / s).mkdir(parents=True, exist_ok=True)
        proj = dict(project_id=project_id, site_id=site_id, created_utc=utc(), software_version=__version__,
                    reference_frame=dict(body="Moon", model="sphere", radius_m=float(radius_m)), mission=mission or {}, study_area=study_area)
        (ws.root / "project.yaml").write_text(yaml.safe_dump(proj, sort_keys=False))
        ws.log("project_created", project_id=project_id, site_id=site_id)
        return ws

    def project(self):
        return yaml.safe_load((self.root / "project.yaml").read_text())

    def log(self, event, **kw):
        with open(self.root / "logs" / "events.jsonl", "a") as f:
            f.write(json.dumps(dict(ts=utc(), event=event, **kw), default=str) + "\n")

    def _save(self, rec):
        p = self.root / "manifests" / f"{rec['id']}.json"
        tmp = p.with_suffix(".tmp"); tmp.write_text(json.dumps(rec, indent=1, default=str)); os.replace(tmp, p)

    def get(self, ds_id):
        return json.loads((self.root / "manifests" / f"{ds_id}.json").read_text())

    def datasets(self):
        return [json.loads(p.read_text()) for p in sorted((self.root / "manifests").glob("*.json"))]

    def raster(self, ds_id, load=True):
        return geo.read_geotiff(str(self.root / self.get(ds_id)["stored_path"]), load_data=load)

    def effective_type(self, ds_id):
        t = self.get(ds_id).get("dataset_type", {})
        return t.get("confirmed") or (t.get("suggested") if t.get("identification_status") == "IDENTIFIED" else None)

    # ---------------------------------------------------------------- ingestion
    def ingest(self, path, data_class="unspecified", provenance=None):
        assert data_class in DATA_CLASSES
        p = Path(path); sha = sha256_file(p); ds_id = "ds_" + sha[:12]
        if (self.root / "manifests" / f"{ds_id}.json").exists():
            return self.get(ds_id)                              # identical content already ingested
        dest = self.root / "originals" / f"{sha[:12]}_{p.name}"
        shutil.copy2(p, dest); os.chmod(dest, 0o444)
        proj = self.project()
        hint = site_hint(p.name); pid = site_hint(proj["site_id"])
        rec = dict(id=ds_id, kind="original", original_filename=p.name, sha256=sha, size_bytes=p.stat().st_size,
                   stored_path=str(dest.relative_to(self.root)), ingested_utc=utc(), software_version=__version__,
                   site=dict(project_site_id=proj["site_id"], filename_hint=f"Site {hint}" if hint is not None else None,
                             hint_agrees=None if hint is None else hint == pid,
                             note=("filename suggests a different site number; the project identity is retained (identity is never inferred from filenames)"
                                   if hint is not None and hint != pid else "identity assigned by project, not by filename")),
                   provenance=dict(provenance or {}), processing_history=[])
        ext = p.suffix.lower()
        if ext not in (".tif", ".tiff"):
            ad = ADAPTERS.get(ext, ("unknown format", "unsupported"))
            rec |= dict(status="STORED_NOT_PARSED", data_class=data_class, adapter=dict(name=ad[0], status=ad[1]),
                        quality=None, message=f"original preserved; no analysis possible: {ad[1]}")
            self._save(rec); self.log("ingested_not_parsed", id=ds_id, file=p.name); return rec
        r, err = None, None
        try:
            r = geo.read_geotiff(str(dest))
        except Exception as e:                                   # corrupt/truncated/unsupported compression
            err = f"{type(e).__name__}: {e}"
        if r is None:
            rec |= dict(status="UNREADABLE", data_class=data_class, quality=validate.run_checks(None, err), message=err)
            self._save(rec); self.log("ingest_unreadable", id=ds_id, file=p.name, error=err); return rec
        z = r.as_float(); v = z[np.isfinite(z)]
        v = v[:: max(1, v.size // 2_000_000)] if v.size else v
        ident = identify.identify(p.name, r.units, r.description, r.tags, v if v.size else None)
        synth = str(r.tags.get("SYNTHETIC", "")).lower() == "true"
        spacing = None
        try:
            dx, dy, info = geo.ground_spacing(r)
            spacing = dict(mean_dx_m=float(np.nanmean(dx)), mean_dy_m=float(np.nanmean(dy)), method=info)
        except geo.UnsupportedError as e:
            spacing = dict(error=str(e))
        rec |= dict(status="READY", data_class="simulated" if synth else data_class, synthetic=synth,
                    format="GeoTIFF", shape=list(r.shape), dtype=r.dtype, bands=r.bands, units=r.units, nodata=r.nodata, description=r.description,
                    crs=r.crs.summary(), native_pixel_size=[r.georef.sx, r.georef.sy] if r.georef else None, ground_spacing=spacing,
                    bounds_native=list(r.bounds) if r.georef else None,
                    coverage_lonlat=geo.lonlat_bbox(r) if r.georef and (r.crs.model == "geographic" or r.crs.projection == "polar_stereographic") else None,
                    instrument_source=dict(source=r.tags.get("LUNASELECT_SOURCE") or rec["provenance"].get("source") or "not declared",
                                           instrument=r.tags.get("INSTRUMENT_ID") or rec["provenance"].get("instrument") or "not declared",
                                           product_id=r.tags.get("PRODUCT_ID") or rec["provenance"].get("product_id") or "not declared"),
                    acquisition_date=r.tags.get("ACQUISITION_DATE") or r.tags.get("TIFFTAG_DATETIME"),
                    tags=r.tags, scale_offset=[r.scale, r.offset])
        rec["dataset_type"] = dict(suggested=ident["suggested_type"], identification_status=ident["status"], reason=ident["reason"],
                                   needs_user_confirmation=ident["needs_user_confirmation"], candidates=ident["candidates"], confirmed=None, confirmed_by=None, note=None)
        rec["quality"] = validate.run_checks(r, None, ident["suggested_type"] if ident["status"] == "IDENTIFIED" else None, proj["reference_frame"]["radius_m"], proj.get("study_area"))
        rec["processing_history"].append(dict(step="ingest", ts=utc(), software_version=__version__, note="original stored read-only; no pixel modification"))
        self._save(rec); self.log("ingested", id=ds_id, file=p.name, identification=ident["status"], quality=rec["quality"]["status"])
        return rec

    def confirm_type(self, ds_id, dtype, user, note=""):
        if dtype not in identify.TYPES:
            raise ValueError(f"unknown dataset type '{dtype}'")
        rec = self.get(ds_id)
        rec["dataset_type"] |= dict(confirmed=dtype, confirmed_by=user, note=note, confirmed_utc=utc())
        r = self.raster(ds_id); proj = self.project()
        rec["quality"] = validate.run_checks(r, None, dtype, proj["reference_frame"]["radius_m"], proj.get("study_area"))
        rec["processing_history"].append(dict(step="confirm_type", ts=utc(), type=dtype, by=user, note=note))
        self._save(rec); self.log("type_confirmed", id=ds_id, type=dtype, by=user)
        return rec

    # ---------------------------------------------------------------- derived products
    def save_derived(self, name, array, like: geo.Raster, units, description, algorithm, params, inputs, extra=None):
        arr = np.where(np.isfinite(array), array, -9999.0).astype(np.float32)
        src = [self.get(i) for i in inputs]; synth = any(s.get("synthetic") for s in src)
        tmp_tags = dict(LUNASELECT_DERIVED="true", LUNASELECT_ALGORITHM=algorithm, SITE_ID=self.project()["site_id"],
                        **({"SYNTHETIC": "true"} if synth else {}))
        path = self.root / "derived" / f"{name}.tif"
        geo.write_geotiff(str(path), arr, like.georef, like.crs.keys, nodata=-9999.0, units=units, description=description, tags=tmp_tags)
        sha = sha256_file(path); ds_id = "dv_" + sha[:12]
        rec = dict(id=ds_id, kind="derived", name=name, stored_path=str(path.relative_to(self.root)), sha256=sha, ingested_utc=utc(), software_version=__version__,
                   units=units, description=description, synthetic=synth, data_class="derived", crs=like.crs.summary(), shape=list(like.shape),
                   native_pixel_size=[like.georef.sx, like.georef.sy], dataset_type=dict(suggested=None, confirmed=None, identification_status="DERIVED"),
                   site=dict(project_site_id=self.project()["site_id"]), valid_fraction=float(np.isfinite(array).mean()),
                   processing_history=[dict(step=algorithm, ts=utc(), software_version=__version__, params=params,
                                            inputs=[dict(id=s["id"], sha256=s["sha256"]) for s in src], output_sha256=sha, **(extra or {}))])
        self._save(rec); self.log("derived", id=ds_id, name=name, algorithm=algorithm); return rec

    def verify_integrity(self):
        bad = []
        for r in self.datasets():
            p = self.root / r["stored_path"]
            if not p.exists() or sha256_file(p) != r["sha256"]:
                bad.append(r["id"])
        return bad
