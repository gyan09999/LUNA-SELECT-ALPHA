"""DEM -> triangle mesh in a local tangent frame (metres) with OBJ / PLY (ASCII) export; GLB only if `trimesh` is installed."""
from __future__ import annotations
import numpy as np
from .geo import UnsupportedError


def dem_mesh(z, dx_m, dy_m, vexag=1.0, stride=1, colors=None):
    """x = east, y = north, z = elevation*vexag (metres), origin at the DEM centre. Cells with any NaN corner are skipped."""
    z = z[::stride, ::stride]; H, W = z.shape
    sx, sy = float(np.nanmean(dx_m)) * stride, float(np.nanmean(dy_m)) * stride
    X, Y = np.meshgrid((np.arange(W) - (W - 1) / 2) * sx, ((H - 1) / 2 - np.arange(H)) * sy)
    v = np.c_[X.ravel(), Y.ravel(), (z * vexag).ravel()]
    idx = np.arange(H * W).reshape(H, W); a, b, c, d = idx[:-1, :-1], idx[:-1, 1:], idx[1:, :-1], idx[1:, 1:]
    ok = np.isfinite(z[:-1, :-1]) & np.isfinite(z[:-1, 1:]) & np.isfinite(z[1:, :-1]) & np.isfinite(z[1:, 1:])
    faces = np.r_[np.c_[a[ok], c[ok], b[ok]], np.c_[b[ok], c[ok], d[ok]]]
    col = None if colors is None else colors[::stride, ::stride].reshape(-1, 3)
    used = np.unique(faces); remap = -np.ones(len(v), int); remap[used] = np.arange(len(used))
    return v[used], remap[faces], (col[used] if col is not None else None)


def _hdr(meta, pre):
    return "".join(f"{pre} {k}: {v}\n" for k, v in meta.items())


def write_obj(path, verts, faces, meta):
    with open(path, "w") as f:
        f.write(_hdr(meta, "#")); f.write("o terrain\n")
        f.writelines(f"v {x:.4f} {y:.4f} {z:.4f}\n" for x, y, z in verts)
        f.writelines(f"f {a + 1} {b + 1} {c + 1}\n" for a, b, c in faces)


def write_ply(path, verts, faces, colors, meta):
    with open(path, "w") as f:
        f.write("ply\nformat ascii 1.0\n" + _hdr(meta, "comment") + f"element vertex {len(verts)}\nproperty float x\nproperty float y\nproperty float z\n")
        if colors is not None: f.write("property uchar red\nproperty uchar green\nproperty uchar blue\n")
        f.write(f"element face {len(faces)}\nproperty list uchar int vertex_indices\nend_header\n")
        for i, (x, y, z) in enumerate(verts):
            f.write(f"{x:.4f} {y:.4f} {z:.4f}" + (" %d %d %d" % tuple(colors[i]) if colors is not None else "") + "\n")
        f.writelines(f"3 {a} {b} {c}\n" for a, b, c in faces)


def write_glb(path, verts, faces, colors=None):
    try:
        import trimesh
    except ImportError as e:
        raise UnsupportedError("GLB export needs the optional 'trimesh' package (not installed)") from e
    trimesh.Trimesh(verts, faces, vertex_colors=colors, process=False).export(path)
