"""Native GeoTIFF I/O and lunar CRS handling (tifffile + NumPy; no GDAL needed).

Scope (Phase 1): north-up, unrotated GeoTIFF; geographic (lon/lat) and polar-stereographic
projections on a spherical body. Everything else is reported as unsupported, never guessed.
"""
from __future__ import annotations
import math, xml.etree.ElementTree as ET
from dataclasses import dataclass, field
import numpy as np, tifffile

MOON_R = 1737400.0                      # m, IAU mean radius
T_SCALE, T_TIE, T_TRANS, T_GKD, T_GDBL, T_GASC, T_GDALMD, T_NODATA = 33550, 33922, 34264, 34735, 34736, 34737, 42112, 42113


class UnsupportedError(Exception):
    """Raised when data cannot be handled correctly (never silently approximated)."""


# ---------------------------------------------------------------- GeoKeys
def parse_geokeys(gkd, gdbl, gasc) -> dict:
    keys: dict = {}
    if gkd is None or len(gkd) < 4:
        return keys
    for i in range(int(gkd[3])):
        kid, loc, cnt, off = (int(v) for v in gkd[4 + 4 * i: 8 + 4 * i])
        if loc == 0:
            keys[kid] = off
        elif loc == T_GDBL and gdbl is not None:
            keys[kid] = float(gdbl[off]) if cnt == 1 else tuple(float(v) for v in gdbl[off:off + cnt])
        elif loc == T_GASC and gasc is not None:
            keys[kid] = str(gasc)[off:off + cnt].rstrip("|\x00 ")
    return keys


def build_geokeys(entries: dict):
    out, dbl, asc = [], [], ""
    for kid in sorted(entries):
        v = entries[kid]
        if isinstance(v, str):
            s = v + "|"; out.append((kid, T_GASC, len(s), len(asc))); asc += s
        elif isinstance(v, float):
            out.append((kid, T_GDBL, 1, len(dbl))); dbl.append(v)
        else:
            out.append((kid, 0, 1, int(v)))
    return [1, 1, 0, len(out)] + [x for t in out for x in t], dbl, asc


def moon_geographic_keys(radius=MOON_R):
    return {1024: 2, 1025: 1, 1026: "Moon sphere (LunaSelect)", 2048: 32767, 2050: 32767, 2056: 32767,
            2057: float(radius), 2059: 0.0, 2054: 9102}


def moon_polar_stereo_keys(south=True, lon0=0.0, k0=1.0, radius=MOON_R):
    return {1024: 1, 1025: 1, 1026: "Moon polar stereographic", 2048: 32767, 2050: 32767, 2056: 32767, 2057: float(radius),
            2059: 0.0, 2054: 9102, 3072: 32767, 3074: 32767, 3075: 15, 3076: 9001, 3081: -90.0 if south else 90.0,
            3095: float(lon0), 3092: float(k0), 3082: 0.0, 3083: 0.0}


def earth_wgs84_keys():
    return {1024: 2, 1025: 1, 2048: 4326}


# ---------------------------------------------------------------- CRS
@dataclass
class CrsInfo:
    model: str = "unknown"                # geographic | projected | unknown
    body: str = "unknown"                 # moon | earth | other | unknown
    semi_major_m: float | None = None
    inv_flattening: float | None = None
    epsg: int | None = None
    citation: str = ""
    projection: str | None = None         # polar_stereographic | other | None
    params: dict = field(default_factory=dict)
    linear_unit_m: float = 1.0
    keys: dict = field(default_factory=dict)

    def summary(self) -> dict:
        return {k: getattr(self, k) for k in ("model", "body", "semi_major_m", "inv_flattening", "epsg", "citation",
                                              "projection", "params", "linear_unit_m")}


def _earth_epsg(c):
    return c is not None and c != 32767 and (c < 30000 or 32601 <= c <= 32760)


def crs_from_keys(keys: dict) -> CrsInfo:
    if not keys:
        return CrsInfo()
    model = {1: "projected", 2: "geographic"}.get(keys.get(1024), "unknown")
    a = keys.get(2057)
    a = a if isinstance(a, float) else None
    epsg = next((keys[k] for k in (3072, 2048) if keys.get(k) not in (None, 32767)), None)
    if a is not None:
        body = "moon" if abs(a - MOON_R) / MOON_R < 0.01 else "earth" if 6.35e6 < a < 6.40e6 else "other"
    else:
        body = "earth" if _earth_epsg(epsg) else "unknown"
    info = CrsInfo(model=model, body=body, semi_major_m=a, inv_flattening=keys.get(2059), epsg=epsg,
                   citation=" | ".join(str(keys[k]) for k in (1026, 2049, 3073) if k in keys), keys=dict(keys))
    if model == "projected":
        lin = {9001: 1.0, 9002: 0.3048}.get(keys.get(3076, 9001))
        info.linear_unit_m = lin if lin else float("nan")
        lat0 = keys.get(3081, keys.get(3085))
        info.params = dict(lat0=lat0, lon0=keys.get(3095, keys.get(3080, keys.get(3088, 0.0))), k0=keys.get(3092, 1.0),
                           fe=keys.get(3082, 0.0), fn=keys.get(3083, 0.0))
        polar = keys.get(3075) in (14, 15) and isinstance(lat0, float) and abs(abs(lat0) - 90) < 1e-9
        info.projection = "polar_stereographic" if polar else "other"
    return info


# ---------------------------------------------------------------- Raster
@dataclass
class GeoRef:
    x0: float; y0: float; sx: float; sy: float      # upper-left corner of UL pixel; pixel size (positive, north-up)
    rotated: bool = False


@dataclass
class Raster:
    path: str
    shape: tuple
    dtype: str
    bands: int
    georef: GeoRef | None
    crs: CrsInfo
    nodata: float | None
    units: str | None
    description: str | None
    tags: dict
    scale: float = 1.0
    offset: float = 0.0
    data: np.ndarray | None = None        # band 1, native dtype (unscaled)

    @property
    def bounds(self):
        g, (h, w) = self.georef, self.shape
        return (g.x0, g.y0 - h * g.sy, g.x0 + w * g.sx, g.y0)   # left, bottom, right, top

    def nodata_mask(self) -> np.ndarray:
        d = self.data
        m = ~np.isfinite(d) if d.dtype.kind == "f" else np.zeros(d.shape, bool)
        if self.nodata is not None:
            m |= np.isnan(d) if math.isnan(self.nodata) else (d == np.asarray(self.nodata).astype(d.dtype))
        return m

    def as_float(self) -> np.ndarray:
        """float32 array, NoData -> NaN, scale/offset applied (record this in processing history)."""
        z = self.data.astype(np.float32)
        z[self.nodata_mask()] = np.nan
        if self.scale != 1 or self.offset != 0:
            z = z * np.float32(self.scale) + np.float32(self.offset)
        return z


def _parse_gdal_md(xml):
    ds, band = {}, {}
    if not xml:
        return ds, band
    try:
        for it in ET.fromstring(str(xml).strip("\x00 \n")).iter("Item"):
            name, role, txt = it.get("name"), it.get("role"), (it.text or "").strip()
            if it.get("sample") is None:
                ds[name] = txt
            elif it.get("sample") == "0":
                band[role or name] = txt
    except ET.ParseError:
        ds["_metadata_parse_error"] = "GDAL_METADATA XML could not be parsed"
    return ds, band


def read_geotiff(path: str, load_data: bool = True) -> Raster:
    with tifffile.TiffFile(path) as tif:
        pg = tif.pages[0]
        tags = {t.code: t.value for t in pg.tags.values()}
        keys = parse_geokeys(tags.get(T_GKD), tags.get(T_GDBL), tags.get(T_GASC))
        crs = crs_from_keys(keys)
        georef = None
        if tags.get(T_TRANS):
            m = list(tags[T_TRANS])
            georef = GeoRef(m[3], m[7], abs(m[0]), abs(m[5]), rotated=(m[1] != 0 or m[4] != 0))
        elif tags.get(T_SCALE) and tags.get(T_TIE):
            sx, sy = tags[T_SCALE][:2]; i, j, _, x, y, _ = tags[T_TIE][:6]
            georef = GeoRef(x - i * sx, y + j * sy, sx, sy)
        if georef and keys.get(1025) == 2:         # PixelIsPoint -> pixel corner
            georef.x0 -= georef.sx / 2; georef.y0 += georef.sy / 2
        nd = tags.get(T_NODATA)
        try:
            nd = float(str(nd).strip("\x00 ")) if nd is not None else None
        except ValueError:
            nd = None
        dsmd, bmd = _parse_gdal_md(tags.get(T_GDALMD))
        arr = pg.asarray() if load_data else None
        if arr is not None and arr.ndim == 3:
            arr = arr[0] if pg.planarconfig == 2 else arr[..., 0]
        return Raster(path=path, shape=(int(pg.imagelength), int(pg.imagewidth)), dtype=str(pg.dtype),
                      bands=int(pg.samplesperpixel), georef=georef, crs=crs, nodata=nd, units=bmd.get("unittype"),
                      description=bmd.get("description"), tags=dsmd, scale=float(bmd.get("scale", 1.0)),
                      offset=float(bmd.get("offset", 0.0)), data=arr)


def write_geotiff(path, arr, georef: GeoRef, crs_keys: dict, nodata=None, units=None, description=None, tags=None):
    gkd, dbl, asc = build_geokeys(crs_keys)
    md = ["<GDALMetadata>"] + [f'<Item name="{k}">{v}</Item>' for k, v in (tags or {}).items()]
    if units: md.append(f'<Item name="UNITTYPE" sample="0" role="unittype">{units}</Item>')
    if description: md.append(f'<Item name="DESCRIPTION" sample="0" role="description">{description}</Item>')
    md.append("</GDALMetadata>")
    ex = [(T_SCALE, "d", 3, (georef.sx, georef.sy, 0.0), True), (T_TIE, "d", 6, (0, 0, 0, georef.x0, georef.y0, 0), True),
          (T_GKD, "H", len(gkd), gkd, True), (T_GDALMD, "s", 0, "".join(md), True)]
    if dbl: ex.append((T_GDBL, "d", len(dbl), dbl, True))
    if asc: ex.append((T_GASC, "s", 0, asc, True))
    if nodata is not None: ex.append((T_NODATA, "s", 0, repr(float(nodata)), True))
    tifffile.imwrite(path, np.ascontiguousarray(arr), photometric="minisblack", metadata=None, extratags=ex)


# ---------------------------------------------------------------- geometry
def ground_spacing(r: Raster, scale_correction: bool = True):
    """(dx_m, dy_m, info): scalars or arrays broadcastable to the raster shape.
    Geographic: R cos(lat) dlon and R dlat. Polar stereographic: grid size / point scale k = 2k0/(1+cos c)."""
    g, c = r.georef, r.crs
    if g is None or c.body not in ("moon", "other") or not c.semi_major_m:
        raise UnsupportedError("CRS body/radius unknown: cannot derive ground spacing")
    R, (h, w) = c.semi_major_m, r.shape
    if c.model == "geographic":
        cl = np.cos(np.radians(g.y0 - (np.arange(h) + .5) * g.sy))
        dx = np.where(cl > 1e-3, R * cl * math.radians(g.sx), np.nan)[:, None]
        return dx, R * math.radians(g.sy), f"geographic sphere R={R:.0f} m; dx=R*cos(lat)*dlon, dy=R*dlat"
    if c.projection == "polar_stereographic" and c.linear_unit_m == c.linear_unit_m:
        p, u = c.params, c.linear_unit_m
        if not scale_correction:
            return g.sx * u, g.sy * u, "polar stereographic: nominal grid spacing (scale factor NOT applied)"
        x = (g.x0 + (np.arange(w) + .5) * g.sx - p["fe"]) * u
        y = (g.y0 - (np.arange(h) + .5) * g.sy - p["fn"]) * u
        cc = 2 * np.arctan(np.hypot(x[None, :], y[:, None]) / (2 * R * p["k0"]))
        k = 2 * p["k0"] / (1 + np.cos(cc))
        return g.sx * u / k, g.sy * u / k, f"polar stereographic R={R:.0f} m k0={p['k0']}: grid spacing / k, k=2k0/(1+cos c)"
    raise UnsupportedError(f"unsupported projection '{c.projection}' ({c.model}); reproject to lon/lat or polar stereographic")


def lonlat_of(r: Raster, rows, cols):
    """Pixel-centre (lon, lat) in degrees for geographic or polar-stereographic rasters."""
    g, c = r.georef, r.crs
    rows, cols = np.asarray(rows, float), np.asarray(cols, float)
    x, y = g.x0 + (cols + .5) * g.sx, g.y0 - (rows + .5) * g.sy
    if c.model == "geographic":
        return x, y
    if c.projection == "polar_stereographic":
        p, S, R = c.params, (1 if c.params["lat0"] > 0 else -1), c.semi_major_m
        x, y = (x - p["fe"]) * c.linear_unit_m, (y - p["fn"]) * c.linear_unit_m
        cc = 2 * np.arctan(np.hypot(x, y) / (2 * R * p["k0"]))
        return (p["lon0"] + np.degrees(np.arctan2(x, -S * y)) + 180) % 360 - 180, S * (90 - np.degrees(cc))
    raise UnsupportedError("lon/lat conversion unsupported for this projection")


def lonlat_bbox(r: Raster, n=25):
    h, w = r.shape
    rr, cc = np.meshgrid(np.linspace(0, h - 1, n), np.linspace(0, w - 1, n), indexing="ij")
    lon, lat = lonlat_of(r, rr, cc)
    return dict(lon_min=float(lon.min()), lon_max=float(lon.max()), lat_min=float(lat.min()), lat_max=float(lat.max()),
                note="sampled on a 25x25 grid; longitude may wrap at +/-180 or the area may contain the pole")


# ---------------------------------------------------------------- forward projection, local axes, resampling
def xy_of(crs: CrsInfo, lon, lat):
    """Forward projection lon/lat (deg) -> native map x, y (file units)."""
    lon, lat = np.asarray(lon, float), np.asarray(lat, float)
    if crs.model == "geographic":
        return lon, lat
    if crs.projection == "polar_stereographic":
        p, R = crs.params, crs.semi_major_m
        S = 1 if p["lat0"] > 0 else -1
        rho = 2 * R * p["k0"] * np.tan(np.radians(90 - S * lat) / 2)
        a = np.radians(lon - p["lon0"])
        return rho * np.sin(a) / crs.linear_unit_m + p["fe"], -S * rho * np.cos(a) / crs.linear_unit_m + p["fn"]
    raise UnsupportedError("forward projection unsupported for this CRS")


def pixel_of(r: Raster, lon, lat):
    """Fractional (row, col) in pixel-centre index coordinates for lon/lat."""
    x, y = xy_of(r.crs, lon, lat)
    if r.crs.model == "geographic":
        x = (x - r.georef.x0 + 180) % 360 - 180 + r.georef.x0 if False else x
    return (r.georef.y0 - y) / r.georef.sy - .5, (x - r.georef.x0) / r.georef.sx - .5


def local_axes(r: Raster, rows, cols):
    """Unit vectors of local east and north expressed in native map (x, y) axes: (ex, ey, nx, ny)."""
    c = r.crs
    rows = np.asarray(rows, float); one = np.ones_like(rows)
    if c.model == "geographic":
        return one, 0 * one, 0 * one, one
    lon, _ = lonlat_of(r, rows, cols)
    a = np.radians(lon - c.params["lon0"])
    if c.params["lat0"] < 0:
        return np.cos(a), -np.sin(a), np.sin(a), np.cos(a)
    return np.cos(a), np.sin(a), -np.sin(a), np.cos(a)


def resample(src: Raster, dst: Raster, method: str = "bilinear"):
    """Resample band 1 of `src` onto the grid/CRS of `dst` (a Raster skeleton: georef, crs, shape).
    NoData is never filled: output is NaN unless the full interpolation neighbourhood is valid.
    Returns (array, manifest). Resampling never increases native resolution; this is recorded."""
    from scipy.ndimage import map_coordinates
    h, w = dst.shape
    rr, cc = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    lon, lat = lonlat_of(dst, rr, cc)
    prow, pcol = pixel_of(src, lon, lat)
    z = src.as_float(); ok = np.isfinite(z); order = 1 if method == "bilinear" else 0
    num = map_coordinates(np.where(ok, z, 0.0), [prow, pcol], order=order, mode="constant", cval=0.0, prefilter=False)
    den = map_coordinates(ok.astype(np.float32), [prow, pcol], order=order, mode="constant", cval=0.0, prefilter=False)
    out = np.where(den > 0.999, num / np.maximum(den, 1e-9), np.nan).astype(np.float32)
    s_dx, s_dy, _ = ground_spacing(src); d_dx, d_dy, _ = ground_spacing(dst)
    s_sp, d_sp = float(np.nanmean(np.sqrt(s_dx * s_dy))), float(np.nanmean(np.sqrt(d_dx * d_dy)))
    return out, dict(method=method, source_spacing_m=s_sp, target_spacing_m=d_sp, spacing_ratio_src_over_dst=s_sp / d_sp,
                     oversampled=bool(d_sp < s_sp / 1.05), native_resolution_m=s_sp,
                     warning=("target grid is finer than the source: values are interpolated; native resolution remains %.2f m" % s_sp)
                     if d_sp < s_sp / 1.05 else None, valid_fraction=float(np.isfinite(out).mean()))
