"""Illumination, solar incidence and Earth visibility on a DEM with terrain horizon (ray marching).

Inputs: a Raster (georef + lunar CRS) and its float DEM. Sun/Earth directions come from `ephemeris` per pixel.
Limits: DEM-only horizon (terrain beyond the DEM edge is unknown -> pixels flagged 'incomplete'); smooth-sphere
curvature drop included; Sun treated as a disk (upper-limb criterion), Earth by its centre; no thermal/penumbra model.
"""
from __future__ import annotations
import numpy as np
from scipy.ndimage import map_coordinates
from . import ephemeris as eph
from .geo import Raster, ground_spacing, lonlat_of, local_axes, MOON_R
from .terrain import horn_gradient

SUN_LIMB_DEG = 0.267


def pixel_geometry(r: Raster):
    h, w = r.shape
    rr, cc = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    lon, lat = lonlat_of(r, rr, cc)
    ex, ey, nx, ny = local_axes(r, rr, cc)
    dx, dy, info = ground_spacing(r)
    return dict(lon=lon, lat=lat, ex=ex, ey=ey, nx=nx, ny=ny, dxg=np.broadcast_to(dx, (h, w)), dyg=np.broadcast_to(dy, (h, w)), spacing_info=info)


def blocked_by_terrain(z, dxg, dyg, gx, gy, el_deg, max_dist_m, step_m, limb_deg=0.0, radius_m=MOON_R):
    """Ray-march from every pixel toward the body. Returns (blocked, incomplete).
    blocked: terrain horizon >= body elevation + limb. incomplete: ray left the DEM/hit NoData before max distance and
    was not already blocked (the true horizon there is unknown)."""
    h, w = z.shape
    rows, cols = np.mgrid[:h, :w].astype(np.float64)
    zf = np.where(np.isfinite(z), z, np.nan)
    top = np.tan(np.radians(np.asarray(el_deg) + limb_deg))
    best = np.full(z.shape, -np.inf); incomplete = np.zeros(z.shape, bool)
    for k in range(1, int(np.ceil(max_dist_m / step_m)) + 1):
        d = k * step_m
        c = cols + gx * d / dxg; r = rows - gy * d / dyg
        inside = (r >= 0) & (r <= h - 1) & (c >= 0) & (c <= w - 1)
        zs = map_coordinates(zf, [np.clip(r, 0, h - 1), np.clip(c, 0, w - 1)], order=1, mode="nearest")
        ang = (zs - z - d * d / (2 * radius_m)) / d
        ok = inside & np.isfinite(ang)
        best = np.where(ok & (ang > best), ang, best)
        incomplete |= ~ok
    blocked = best >= top
    return blocked, incomplete & ~blocked


def _dir_grid(g, az_deg):
    a = np.radians(az_deg)
    return np.sin(a) * g["ex"] + np.cos(a) * g["nx"], np.sin(a) * g["ey"] + np.cos(a) * g["ny"]


def _series(r, z, times_unix, which, max_dist_m, step_m):
    g = pixel_geometry(r); step_h = float(np.median(np.diff(times_unix))) / 3600.0 if len(times_unix) > 1 else 0.0
    vis_n = np.zeros(z.shape); inc_n = np.zeros(z.shape); cur = np.zeros(z.shape); cur_dark = np.zeros(z.shape)
    long_vis = np.zeros(z.shape); long_dark = np.zeros(z.shape)
    for t in times_unix:
        if which == "sun":
            el, az = eph.sun_look(g["lat"], g["lon"], t); limb = SUN_LIMB_DEG
        else:
            el, az = eph.earth_look(g["lat"], g["lon"], t); limb = 0.0
        gx, gy = _dir_grid(g, az)
        blocked, incomplete = blocked_by_terrain(z, g["dxg"], g["dyg"], gx, gy, el, max_dist_m, step_m, limb)
        vis = (el + limb > 0) & ~blocked
        vis_n += vis; inc_n += incomplete & (el + limb > 0)
        cur = np.where(vis, cur + step_h, 0.0); long_vis = np.maximum(long_vis, cur)
        cur_dark = np.where(~vis, cur_dark + step_h, 0.0); long_dark = np.maximum(long_dark, cur_dark)
    n = len(times_unix); inv = ~np.isfinite(z)
    mask = lambda a: np.where(inv, np.nan, a).astype(np.float32)
    return dict(fraction=mask(vis_n / n), longest_visible_h=mask(long_vis), longest_outage_h=mask(long_dark),
                incomplete_fraction=mask(inc_n / n), n_steps=n, step_h=step_h)


def illumination_series(r, z, times_unix, max_dist_m=5000.0, step_m=None):
    """Sunlit fraction and longest lit/dark durations over the supplied UTC times (temporal resolution = step)."""
    sp = float(np.nanmean(np.sqrt(ground_spacing(r)[0] * ground_spacing(r)[1])))
    return _series(r, z, np.asarray(times_unix, float), "sun", max_dist_m, step_m or sp)


def earth_visibility_series(r, z, times_unix, max_dist_m=5000.0, step_m=None):
    sp = float(np.nanmean(np.sqrt(ground_spacing(r)[0] * ground_spacing(r)[1])))
    return _series(r, z, np.asarray(times_unix, float), "earth", max_dist_m, step_m or sp)


def instant_state(r, z, t_unix, max_dist_m=5000.0, step_m=None):
    """Sun/Earth elevation-azimuth, terrain shadow, Earth visibility and solar incidence at one UTC instant."""
    g = pixel_geometry(r); sp = step_m or float(np.nanmean(np.sqrt(g["dxg"] * g["dyg"])))
    out = {}
    for which, fn, limb in (("sun", eph.sun_look, SUN_LIMB_DEG), ("earth", eph.earth_look, 0.0)):
        el, az = fn(g["lat"], g["lon"], t_unix); gx, gy = _dir_grid(g, az)
        blocked, inc = blocked_by_terrain(z, g["dxg"], g["dyg"], gx, gy, el, max_dist_m, sp, limb)
        out[which] = dict(el=el, az=az, visible=(el + limb > 0) & ~blocked, incomplete=inc)
    dzdx, dzdy = horn_gradient(z, g["dxg"], g["dyg"])
    gE, gN = dzdx * g["ex"] + dzdy * g["ey"], dzdx * g["nx"] + dzdy * g["ny"]
    e, a = np.radians(out["sun"]["el"]), np.radians(out["sun"]["az"])
    cosi = (-gE * np.sin(a) * np.cos(e) - gN * np.cos(a) * np.cos(e) + np.sin(e)) / np.sqrt(1 + gE ** 2 + gN ** 2)
    out["incidence_deg"] = np.where(out["sun"]["visible"], np.degrees(np.arccos(np.clip(cosi, -1, 1))), np.nan).astype(np.float32)
    return out
