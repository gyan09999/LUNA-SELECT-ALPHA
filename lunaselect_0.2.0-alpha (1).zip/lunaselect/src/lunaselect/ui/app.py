"""LunaSelect engineering console (Streamlit). Shows only values computed from workspace data.
Run:  streamlit run src/lunaselect/ui/app.py
STATUS: written against the tested core API; exercised only with a stubbed Streamlit object in tests (no real browser run)."""
from __future__ import annotations
import datetime as dt, json, subprocess, sys, tempfile
from pathlib import Path
import numpy as np, yaml
import streamlit as st
from lunaselect import __version__, factors as F, geo, identify, pipeline, report, scoring as S, validate, environment as env, terrain, cli
from lunaselect.workspace import ADAPTERS, Workspace

MODULES = ["Mission Overview", "Project Manager", "Raw Data Laboratory", "GIS Validation", "Terrain Analysis", "Environmental Analysis",
           "Resource Assessment", "3D Explorer", "Safety Gates", "Suitability Engine", "Uncertainty Lab", "Multi-Site Comparison",
           "Verification Centre", "Report Generator"]


def _ws():
    p = st.session_state.get("ws_path")
    return Workspace(p) if p and (Path(p) / "project.yaml").exists() else None


def _need(ws):
    if ws is None: st.warning("No workspace open. Use Project Manager."); return True
    return False


def _result(ws):
    f = ws.root / "reports" / "site_result.json"
    return json.loads(f.read_text()) if f.exists() else None


def _dems(ws):
    return [d for d in ws.datasets() if d["kind"] == "original" and d.get("status") == "READY" and ws.effective_type(d["id"]) == "dem"]


def page_overview(ws):
    st.title("Mission Overview"); st.caption(f"LunaSelect {__version__}: independent research software; not NASA/JPL developed, approved or certified.")
    if _need(ws): return
    p = ws.project(); st.write(f"Project **{p['project_id']}** | site identity **{p['site_id']}** | reference sphere R = {p['reference_frame']['radius_m']:.0f} m")
    ds = ws.datasets(); st.metric("Datasets", len(ds)); res = _result(ws)
    rows = [dict(id=f.id, factor=f.name, implementation=f.status, assessed=bool(res and res["factor_inputs"].get(f.key, {}).get("stat") is not None)) for f in F.FACTORS]
    st.dataframe(rows); st.info("Catalogue is a proposal requiring mission-specific engineering approval.")
    if any(d.get("synthetic") for d in ds): st.error("SYNTHETIC demonstration data present: not lunar measurements.")


def page_project(ws):
    st.title("Project Manager"); path = st.text_input("Workspace folder", st.session_state.get("ws_path", str(Path.home() / "lunaselect_ws")))
    c1, c2, c3 = st.columns(3); pid = c1.text_input("Project id", "LS-PROJECT"); site = c2.text_input("Site identity (assigned, not inferred from filenames)", "Site 11")
    if c3.button("Create workspace"): Workspace.create(path, pid, site); st.session_state["ws_path"] = path
    if st.button("Open existing"): st.session_state["ws_path"] = path
    if st.button("Load SYNTHETIC Site 11 demo"):
        tmp = Path(tempfile.mkdtemp()); cli.demo(tmp); st.session_state["ws_path"] = str(tmp / "workspace")
    ws = _ws()
    if ws:
        st.code(yaml.safe_dump(ws.project(), sort_keys=False)); log = ws.root / "logs" / "events.jsonl"
        if log.exists(): st.text("\n".join(log.read_text().splitlines()[-15:]))


def page_raw(ws):
    st.title("Raw Data Laboratory")
    if _need(ws): return
    cls = st.selectbox("Data class of the files being uploaded", ["unspecified", "raw", "calibrated", "derived", "simulated"])
    for f in st.file_uploader("Upload datasets", accept_multiple_files=True) or []:
        tmp = Path(tempfile.mkdtemp()) / f.name; tmp.write_bytes(f.getvalue()); r = ws.ingest(tmp, cls); st.write(r["original_filename"], r["status"])
    for d in ws.datasets():
        if d["kind"] != "original": continue
        t = d.get("dataset_type", {}); st.subheader(d["original_filename"])
        st.json(dict(id=d["id"], status=d["status"], sha256=d["sha256"], identification=t.get("identification_status"), suggested=t.get("suggested"), site=d["site"]))
        if d["status"] == "READY" and t.get("needs_user_confirmation") and not t.get("confirmed"):
            c = st.selectbox(f"Confirm type for {d['id']}", list(identify.TYPES), key="c" + d["id"]); u = st.text_input("Analyst", key="u" + d["id"])
            if st.button("Confirm", key="b" + d["id"]) and u: ws.confirm_type(d["id"], c, u)
    st.subheader("Reader adapter status"); st.dataframe([dict(ext=k, adapter=v[0], status=v[1]) for k, v in ADAPTERS.items()])


def page_validation(ws):
    st.title("GIS Validation")
    if _need(ws): return
    ready = [d for d in ws.datasets() if d.get("status") == "READY"]
    for d in ready:
        q = d["quality"]; st.subheader(f"{d.get('original_filename') or d.get('name')}: {q['status']}") if q else None
        if q: st.dataframe([dict(id=c["id"], check=c["name"], status=c["status"], message=c["message"]) for c in q["checks"]])
    orig = [d for d in ready if d["kind"] == "original"]
    if len(orig) > 1:
        st.subheader("Grid compatibility")
        for i in range(len(orig)):
            for j in range(i + 1, len(orig)):
                st.write(orig[i]["original_filename"], "vs", orig[j]["original_filename"], validate.compare_grids(ws.raster(orig[i]["id"]), ws.raster(orig[j]["id"])))


def page_terrain(ws):
    st.title("Terrain Analysis")
    if _need(ws): return
    dems = _dems(ws)
    if not dems: st.warning("No dataset is identified/confirmed as a DEM. A slope raster alone cannot be used for terrain analysis or 3D."); return
    sel = st.selectbox("DEM", [d["id"] for d in dems]); cfg_txt = st.text_area("Analysis configuration (YAML)", yaml.safe_dump(pipeline.DEMO_CFG, sort_keys=False), height=260)
    st.caption("The default configuration is EXAMPLE_ONLY for the synthetic demo; thresholds are not mission requirements.")
    if st.button("Run analysis"):
        bar = st.progress(0.0); pipeline.run_site(ws, sel, yaml.safe_load(cfg_txt), progress=lambda m, f: bar.progress(f, text=m))
    res = _result(ws)
    if res:
        st.json(res["factor_inputs"]); cols = st.columns(3)
        for i, n in enumerate(("dem", "hillshade", "slope")):
            p = ws.root / "exports" / f"{n}.png"
            if p.exists(): cols[i].image(str(p), caption=n)


def page_env(ws):
    st.title("Environmental Analysis: Sun and Earth at a chosen UTC time")
    if _need(ws): return
    dems = _dems(ws)
    if not dems: st.warning("DEM required."); return
    r = ws.raster(dems[0]["id"]); z = r.as_float()
    t = st.slider("UTC time (days from 2026-11-10)", 0.0, 29.5, 0.0, 0.25); md = st.number_input("Max shadow distance (m)", 500.0, 20000.0, 2500.0)
    ts = dt.datetime(2026, 11, 10, tzinfo=dt.timezone.utc).timestamp() + t * 86400
    s = env.instant_state(r, z, ts, md)
    c = tuple(x // 2 for x in z.shape); st.write(f"Centre pixel: Sun el {s['sun']['el'][c]:.2f} deg az {s['sun']['az'][c]:.1f} | Earth el {s['earth']['el'][c]:.2f} deg az {s['earth']['az'][c]:.1f}")
    st.write(f"Sunlit {np.nanmean(s['sun']['visible'][np.isfinite(z)]):.1%} | Earth visible {np.nanmean(s['earth']['visible'][np.isfinite(z)]):.1%}. Pixels whose horizon ray left the DEM are 'incomplete'.")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(1, 2, figsize=(9, 4)); ax[0].imshow(s["sun"]["visible"], cmap="gray"); ax[0].set_title("Sunlit (terrain horizon)"); ax[1].imshow(s["earth"]["visible"], cmap="gray"); ax[1].set_title("Earth visible")
    st.pyplot(fig)


def page_resource(ws):
    st.title("Resource Assessment")
    st.warning("Water ice, hydrogen, volatiles and regolith composition need calibrated instrument products with uncertainty. LunaSelect never infers them from terrain.")
    st.dataframe([dict(factor=f.name, required_source=f.source, status=f.status) for f in F.FACTORS if f.group == "resources"])
    if ws:
        types = {ws.effective_type(d["id"]) for d in ws.datasets() if d["kind"] == "original"}
        for f in F.FACTORS:
            if f.group == "resources": st.write(f.name, "NOT ASSESSED" if not (set(f.dataset_types) & types) else "data present: scoring method not implemented (ingest only)")


def page_3d(ws):
    st.title("3D Explorer")
    if _need(ws): return
    dems = _dems(ws)
    if not dems: st.warning("A valid DEM is required. A slope raster alone cannot produce a scientific 3D terrain model."); return
    r = ws.raster(dems[0]["id"]); z = r.as_float(); dx, dy, _ = geo.ground_spacing(r)
    ve = st.slider("Vertical exaggeration", 1.0, 10.0, 2.0); stride = st.slider("Mesh stride (pixels)", 1, 8, 2)
    ov = st.selectbox("Overlay", ["none", "slope", "roughness", "illumination_fraction", "earth_visibility_fraction", "local_relief"])
    show = st.checkbox("Show overlay", True)
    try:
        import plotly.graph_objects as go
    except ImportError:
        st.error("plotly is not installed"); return
    colour = None
    if ov != "none" and show:
        d = next((x for x in ws.datasets() if x.get("name") == ov), None)
        if d: colour = geo.read_geotiff(str(ws.root / d["stored_path"])).as_float()[::stride, ::stride]
    zz = z[::stride, ::stride]; H, W = zz.shape; sx, sy = float(np.nanmean(dx)) * stride, float(np.nanmean(dy)) * stride
    x = (np.arange(W) - (W - 1) / 2) * sx; y = ((H - 1) / 2 - np.arange(H)) * sy
    fig = go.Figure(go.Surface(x=x, y=y, z=zz * ve, surfacecolor=colour, colorscale="Viridis" if colour is not None else "Greys", colorbar=dict(title=ov if colour is not None else "elevation (m)")))
    fig.update_layout(scene=dict(xaxis_title="east (m)", yaxis_title="north (m)", zaxis_title=f"elevation x{ve} (m)", aspectmode="data"), height=650)
    st.plotly_chart(fig); st.caption(f"Local tangent frame; spacing {sx:.1f} x {sy:.1f} m; vertical exaggeration x{ve}; CRS {r.crs.citation or r.crs.model}")
    for fmt in ("obj", "ply", "glb"):
        if st.button(f"Export {fmt.upper()}"):
            try: st.success(str(cli.export_mesh(ws, dems[0]["id"], fmt, ve, stride, ov if ov != "none" else "slope")))
            except geo.UnsupportedError as e: st.error(str(e))


def page_gates(ws):
    st.title("Safety Gates (hard constraints)")
    res = _result(ws) if ws else None
    if not res: st.info("Run the terrain analysis first."); return
    st.dataframe(res["evaluation"]["gates"]); st.write("Overall:", res["evaluation"]["status"]); st.caption("A FAIL is never offset by a high weighted score.")


def page_suit(ws):
    st.title("Suitability Engine")
    res = _result(ws) if ws else None
    if not res: st.info("Run the terrain analysis first."); return
    ev = res["evaluation"]; st.write(f"Relative preference score {ev['score']} over {ev['score_coverage']:.0%} of the weight. Not a probability of landing success.")
    st.dataframe(ev["factors"]); w = {f.key: st.number_input(f.name, 0.0, 100.0, 5.0, key=f.key) for f in F.FACTORS}; j = st.text_input("Justification for non-reference weights")
    try: st.write(F.normalise_weights(w, j))
    except ValueError as e: st.error(str(e))


def page_unc(ws):
    st.title("Uncertainty Lab"); st.info("Rank stability, weight and normalisation sensitivity need two or more comparable sites (see Multi-Site Comparison). Single-site runs: NOT ASSESSED. Input sigma is propagated only where supplied.")


def page_multi(ws):
    st.title("Multi-Site Comparison"); paths = st.text_area("site_result.json paths (one per line)").split()
    if len(paths) < 2: st.info("Provide at least two result files."); return
    inputs, gates, prefs = {}, None, None
    for p in paths:
        r = json.loads(Path(p).read_text()); inputs[r["evaluation"]["site"] + ":" + Path(p).parent.parent.name] = {k: S.FactorInput(**v) for k, v in r["factor_inputs"].items()}; gates, prefs = pipeline.build_gates_prefs(r["config"])
    st.json(S.compare_sites(inputs, gates, prefs), expanded=False)


def page_verify(ws):
    st.title("Verification Centre"); st.caption("Passing tests demonstrates software behaviour on synthetic cases, not mission validation.")
    if ws: st.write("Original-file integrity mismatches:", ws.verify_integrity())
    if st.button("Run automated tests"):
        o = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], capture_output=True, text=True); st.code(o.stderr[-4000:])


def page_report(ws):
    st.title("Report Generator")
    if _need(ws): return
    if st.button("Build JSON / CSV / PDF"):
        try: st.json(report.build_all(ws))
        except FileNotFoundError: st.error("Run the terrain analysis first.")


PAGES = dict(zip(MODULES, [page_overview, page_project, page_raw, page_validation, page_terrain, page_env, page_resource, page_3d, page_gates, page_suit, page_unc, page_multi, page_verify, page_report]))


def main():
    st.set_page_config(page_title="LunaSelect", layout="wide")
    st.markdown("<style>.stApp{background:#0b0f17;color:#dfe6f2}</style>", unsafe_allow_html=True)
    m = st.sidebar.radio("Module", MODULES); PAGES[m](_ws())


if __name__ == "__main__":
    main()
