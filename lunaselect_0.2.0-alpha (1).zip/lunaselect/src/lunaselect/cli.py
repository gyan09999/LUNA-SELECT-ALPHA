"""LunaSelect command line (offline). `python -m lunaselect demo OUT` runs the full SYNTHETIC Site 11 pipeline."""
from __future__ import annotations
import argparse, json, shutil, sys
import numpy as np
from pathlib import Path
import yaml
from . import __version__, synthetic, pipeline, report, meshio, quicklook, geo, terrain, environment
from .workspace import Workspace


def export_mesh(ws, dem_id, fmt="obj", vexag=1.0, stride=1, overlay="slope"):
    r = ws.raster(dem_id); z = r.as_float(); dx, dy, _ = geo.ground_spacing(r)
    cols = None
    ov = next((d for d in ws.datasets() if d.get("name") == overlay), None)
    if ov:
        a = geo.read_geotiff(str(ws.root / ov["stored_path"])).as_float(); lo, hi = (0, 30) if overlay == "slope" else (float(np.nanmin(a)), float(np.nanmax(a)))
        cols = quicklook._cmap((np.nan_to_num(a) - lo) / ((hi - lo) or 1))
    v, f, c = meshio.dem_mesh(z, dx, dy, vexag, stride, cols)
    lon, lat = geo.lonlat_of(r, r.shape[0] // 2, r.shape[1] // 2)
    meta = dict(software=f"LunaSelect {__version__}", crs=r.crs.citation or r.crs.model, body="Moon", radius_m=r.crs.semi_major_m, units="metre (local tangent frame, x=east y=north z=elevation*exaggeration)",
                origin_lon_lat=f"{float(lon):.5f},{float(lat):.5f}", vertical_exaggeration=vexag, source_dem=dem_id, overlay=overlay if cols is not None else "none",
                synthetic=str(ws.get(dem_id).get("synthetic", False)), note="mesh from a DEM; not a model from slope alone")
    p = ws.root / "exports" / f"terrain_{dem_id}.{fmt}"
    {"obj": lambda: meshio.write_obj(p, v, f, meta), "ply": lambda: meshio.write_ply(p, v, f, c, meta), "glb": lambda: meshio.write_glb(p, v, f, c)}[fmt]()
    return p


def demo(out):
    out = Path(out); shutil.rmtree(out, ignore_errors=True)
    pd, ps = synthetic.write_site11_demo(out / "inputs")
    ws = Workspace.create(out / "workspace", "LS-DEMO-SYNTHETIC", "Site 11", mission=dict(type="robotic_lander", note="SYNTHETIC demo"))
    a, b = ws.ingest(pd), ws.ingest(ps)
    res = pipeline.run_site(ws, a["id"], pipeline.DEMO_CFG, progress=lambda m, f: print(f"[{f:4.0%}] {m}"))
    paths = report.build_all(ws); paths["obj"] = str(export_mesh(ws, a["id"], "obj", 2.0, 2)); paths["ply"] = str(export_mesh(ws, a["id"], "ply", 2.0, 2))
    print(json.dumps(dict(status=res["evaluation"]["status"], score=res["evaluation"]["score"], coverage=res["evaluation"]["score_coverage"], outputs=paths), indent=1, default=str))
    return ws


def main(argv=None):
    ap = argparse.ArgumentParser("lunaselect"); sp = ap.add_subparsers(dest="cmd", required=True)
    s = sp.add_parser("demo"); s.add_argument("out")
    s = sp.add_parser("init"); s.add_argument("ws"); s.add_argument("--project", required=True); s.add_argument("--site", required=True)
    s = sp.add_parser("ingest"); s.add_argument("ws"); s.add_argument("files", nargs="+"); s.add_argument("--data-class", default="unspecified")
    s = sp.add_parser("datasets"); s.add_argument("ws")
    s = sp.add_parser("confirm"); s.add_argument("ws"); s.add_argument("id"); s.add_argument("type"); s.add_argument("--user", required=True); s.add_argument("--note", default="")
    s = sp.add_parser("run"); s.add_argument("ws"); s.add_argument("id"); s.add_argument("--config", required=True)
    s = sp.add_parser("report"); s.add_argument("ws")
    s = sp.add_parser("mesh"); s.add_argument("ws"); s.add_argument("id"); s.add_argument("--format", default="obj"); s.add_argument("--vexag", type=float, default=1.0); s.add_argument("--stride", type=int, default=1)
    s = sp.add_parser("verify"); s.add_argument("ws")
    a = ap.parse_args(argv)
    if a.cmd == "demo": demo(a.out); return 0
    if a.cmd == "init": Workspace.create(a.ws, a.project, a.site); return 0
    ws = Workspace(a.ws)
    if a.cmd == "ingest":
        for f in a.files: r = ws.ingest(f, a.data_class); print(r["id"], r["status"], (r.get("dataset_type") or {}).get("identification_status"), (r.get("quality") or {}).get("status"))
    elif a.cmd == "datasets":
        for d in ws.datasets(): print(d["id"], d["kind"], d.get("original_filename") or d.get("name"), d.get("status", "DERIVED"), (d.get("dataset_type") or {}).get("suggested"))
    elif a.cmd == "confirm": ws.confirm_type(a.id, a.type, a.user, a.note)
    elif a.cmd == "run": print(json.dumps(pipeline.run_site(ws, a.id, yaml.safe_load(open(a.config)))["evaluation"], indent=1, default=str))
    elif a.cmd == "report": print(report.build_all(ws))
    elif a.cmd == "mesh": print(export_mesh(ws, a.id, a.format, a.vexag, a.stride))
    elif a.cmd == "verify":
        bad = ws.verify_integrity(); print("integrity OK" if not bad else f"MISMATCH: {bad}"); return 1 if bad else 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
